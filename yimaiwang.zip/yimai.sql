/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50517
Source Host           : localhost:3306
Source Database       : yimai

Target Server Type    : MYSQL
Target Server Version : 50517
File Encoding         : 65001

Date: 2017-04-11 22:06:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ntitle` varchar(50) NOT NULL,
  `ncontent` varchar(500) NOT NULL,
  `ncreatetime` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('1', '迎双旦促销大酬宾', '迎双旦促销大酬宾', '2010-12-24');
INSERT INTO `news` VALUES ('2', '加入会员，赢千万大礼包', '加入会员，赢千万大礼包', '2010-12-22');
INSERT INTO `news` VALUES ('3', '免费送', '全场不要钱 随便搞', '2013-08-14');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` varchar(50) NOT NULL,
  `uid` int(11) NOT NULL,
  `uaddress` varchar(200) NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `totalprices` float NOT NULL,
  `statu` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `oid` (`uid`),
  CONSTRAINT `oid` FOREIGN KEY (`uid`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('1084122861', '6', '湖南省衡阳市祁东县风石堰镇鲜鱼市场', '2017-01-27 10:12:13', '6299.99', '1');
INSERT INTO `orders` VALUES ('1133738796', '3', '白地市镇', '2017-02-20 23:02:14', '23999.2', '0');
INSERT INTO `orders` VALUES ('1327670954', '3', '白地市镇', '2017-01-25 22:03:00', '3174.4', '1');
INSERT INTO `orders` VALUES ('1385455577', '3', '白地市镇', '2017-02-01 22:53:03', '67.2', '1');
INSERT INTO `orders` VALUES ('1428020455', '3', '白地市镇', '2017-01-27 10:30:17', '473', '0');
INSERT INTO `orders` VALUES ('1526124137', '3', '白地市镇', '2017-02-21 12:48:32', '5988', '1');
INSERT INTO `orders` VALUES ('1540002379', '3', '白地市镇', '2017-02-14 14:09:16', '6299.99', '1');
INSERT INTO `orders` VALUES ('1566485034', '3', '白地市镇', '2017-01-27 00:01:03', '1599.99', '1');
INSERT INTO `orders` VALUES ('18060132', '6', '湖南省衡阳市祁东县风石堰镇鲜鱼市场', '2017-01-27 11:26:15', '5988', '1');
INSERT INTO `orders` VALUES ('1937235851', '3', '白地市镇', '2017-02-01 22:37:54', '98802', '1');
INSERT INTO `orders` VALUES ('1971101720', '3', '白地市镇', '2017-02-02 16:50:45', '8999', '1');
INSERT INTO `orders` VALUES ('2046937288', '3', '白地市镇', '2017-02-14 14:10:49', '473', '1');
INSERT INTO `orders` VALUES ('297686444', '3', '白地市镇', '2017-01-27 10:32:26', '2999.9', '0');
INSERT INTO `orders` VALUES ('390797970', '3', '白地市镇', '2017-02-01 22:56:49', '6388', '1');
INSERT INTO `orders` VALUES ('411346810', '3', '白地市镇', '2017-01-25 17:33:50', '18900', '1');
INSERT INTO `orders` VALUES ('699537347', '3', '白地市镇', '2017-02-02 15:02:40', '2365', '1');
INSERT INTO `orders` VALUES ('735244788', '3', '白地市镇', '2017-02-01 22:36:48', '449.7', '1');
INSERT INTO `orders` VALUES ('76452122', '3', '白地市镇', '2017-01-25 18:26:43', '4550.4', '1');
INSERT INTO `orders` VALUES ('821528622', '3', '白地市镇', '2017-01-21 13:19:21', '2999.9', '0');

-- ----------------------------
-- Table structure for order_detail
-- ----------------------------
DROP TABLE IF EXISTS `order_detail`;
CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(100) NOT NULL,
  `pro_count` int(11) NOT NULL,
  `oid` varchar(51) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `oid` (`oid`),
  CONSTRAINT `order_detail_ibfk_1` FOREIGN KEY (`oid`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order_detail
-- ----------------------------
INSERT INTO `order_detail` VALUES ('27', '24', '1', '1327670954');
INSERT INTO `order_detail` VALUES ('28', '10', '1', '1327670954');
INSERT INTO `order_detail` VALUES ('29', '32', '1', '1327670954');
INSERT INTO `order_detail` VALUES ('31', '24', '1', '821528622');
INSERT INTO `order_detail` VALUES ('37', '26', '3', '411346810');
INSERT INTO `order_detail` VALUES ('38', '23', '1', '76452122');
INSERT INTO `order_detail` VALUES ('44', '25', '1', '1566485034');
INSERT INTO `order_detail` VALUES ('45', '26', '1', '1084122861');
INSERT INTO `order_detail` VALUES ('46', '20', '1', '1428020455');
INSERT INTO `order_detail` VALUES ('47', '24', '1', '297686444');
INSERT INTO `order_detail` VALUES ('50', '38', '1', '18060132');
INSERT INTO `order_detail` VALUES ('51', '16', '1', '735244788');
INSERT INTO `order_detail` VALUES ('52', '16', '198', '1937235851');
INSERT INTO `order_detail` VALUES ('53', '8', '1', '1385455577');
INSERT INTO `order_detail` VALUES ('54', '36', '1', '390797970');
INSERT INTO `order_detail` VALUES ('55', '20', '5', '699537347');
INSERT INTO `order_detail` VALUES ('57', '13', '1', '1971101720');
INSERT INTO `order_detail` VALUES ('58', '26', '1', '1540002379');
INSERT INTO `order_detail` VALUES ('60', '20', '1', '2046937288');
INSERT INTO `order_detail` VALUES ('61', '24', '8', '1133738796');
INSERT INTO `order_detail` VALUES ('62', '38', '1', '1526124137');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `p_parentid` int(11) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `inventory` int(11) NOT NULL,
  `detail` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `twoid` (`p_parentid`),
  CONSTRAINT `twoid` FOREIGN KEY (`p_parentid`) REFERENCES `product_two` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('4', '哈利·波特与魔法石（全彩绘本） [6-12岁]', '1', '/yimaiwang/images/product/0/3/09e801d7-d317-4cff-a57a-9046f29e9fb5.jpg', '50.2', '24', '出版社： 人民文学出版社 ISBN：9787020111435版次：1商品编码：11779020包装：平装开本：16开出版时间：2015-10-01用纸：胶版纸页数：241\r\n亲爱的波特先生：\r\n　　我们愉快地通知您，您已获准在霍格沃茨魔法学校就读。随信附上所需书籍及装备一览表。\r\n　　学期定于九月一日开始。我们将于七月三十一日前静候您的猫头鹰带来您的回信。\r\n　　副校长\r\n　　米勒娃·麦格谨上\r\n　　哈利·波特的人生在他十一岁生日那天发生了永远的改变，眼睛像黑甲虫似的巨人鲁伯·海格带给他一封信和很多令人震惊的消息。哈利·波特不是一个普通的男孩，他是一个小巫师。一段非凡的冒险即将开始……\r\n　　这是J。K。罗琳创作的魔法经典的一个彩绘本，书中充满了吉姆·凯绘制的绚丽彩图。这是一场绝对迷人的盛宴，献给忠实的哈迷和新的读者们。');
INSERT INTO `product` VALUES ('5', '小猪唏哩呼噜（注音版 套装共2册） [7-10岁]', '1', '/yimaiwang/images/product/11/11/66469483-e429-44bd-bee3-35277dee5cd7.jpg', '16.5', '5020', '出版社： 春风文艺出版社 ISBN：11234792 版次：1 商品编码：11234792 包装：平装丛书名： aoe 名著 开本：24 开出版时间：2008-06-01用纸：胶版纸页数：312 套装数量：2正文语种：中文\r\n孙幼军先生是我国头一位荣获国际安徒生提名奖的儿童文学作家。怀着对儿童的热爱和对生活的独特解读，他数十年来笔耕不辍，创作了大量经典之作。其童话作品无论在形象塑造亦或语言表述方面都达到了儿童文学的至高水准。代表作《小猪唏哩呼噜》构思精妙，情节丰富，在寓教于乐、活泼幽默的表述中不乏灵动的想象与智慧的启迪。童语化的叙述体现了孙幼军老先生未泯的童心和蓬勃的创作激情，作品富有感染力，阅读性强，易于被小读者理解接受、引起共鸣，也有助于培养小学生的文学素养，提高写作能力。\r\n');
INSERT INTO `product` VALUES ('6', '彩书坊：365夜宝宝睡前故事（珍藏版） [3-6岁]', '1', '/yimaiwang/images/product/12/10/2adde774-ab8a-4123-91e0-185746758dd9.jpg', '19.8', '62', '出版社： 吉林出版集团有限责任公司 ISBN：9787807627418 版次：1商品编码：10113257 包装：精装丛书名：彩书坊 开本：16开出版时间：2008-11-01用纸：胶版纸页数：188字数：60000正文语种：中文\r\n《彩书坊：365夜宝宝睡前故事（珍藏版）》分为春、夏、秋、冬四章，用美丽的图画勾勒孩子的梦幻，用清新的文字编织一部多彩的童话，为孩子们带来了春的梦想、夏的宁静、秋的美丽、冬的晶莹，让孩子们走入经典，在智慧里徜徉。让年轻的父母们与孩子的心灵轻轻贴近，在梦中一起聆听那来自天籁的声音。\r\n　　一年有365天，365个夜晚，365个梦。孩子的心里总是装着许多奇妙的幻想，总有一双想象的翅膀会出现在梦中，总有一首天真的歌谣会回荡在梦中，每当进入香甜的梦乡，365夜那单纯而温婉的故事定能将你带入绮丽的童话世界。\r\n　　《彩书坊：365夜宝宝睡前故事（珍藏版）》将70个中外经典故事汇集成册，堪称世界故事园林中的精粹。引人入胜的故事情节和全彩精美的图画诠释出故事的美丽，适合不同年龄段的孩子阅读：家长可以将本书中的故事讲给阅读能力有限的学龄前儿童听，每个故事的讲述时间不会超过十分钟，而较长的故事则以小标题的形式对情节加以划分；同时本书的正文全部标注汉语拼音，更方便学龄儿童自主阅读，从而培养孩子阅读的独立性，使阅读更科学、更系统，让孩子们在阅读过程中既得到了文学艺术的熏陶，又得到了心灵的感染。');
INSERT INTO `product` VALUES ('7', '百年孤独', '3', '/yimaiwang/images/product/5/9/0dfcd9f3-6af3-48f2-a606-68e339646bb4.jpg', '27.3', '6', '出版社： 南海出版公司 ISBN：9787544253994版次：1商品编码：10658646包装：精装开本：32开出版时间：2011-06-01用纸：胶版纸页数：360正文语种：中文\r\n内容简介：\r\n《百年孤独》是魔幻现实主义文学的代表作，描写了布恩迪亚家族七代人的传奇故事，以及加勒比海沿岸小镇马孔多的百年兴衰，反映了拉丁美洲一个世纪以来风云变幻的历史。作品融入神话传说、民间故事、宗教典故等神秘因素，巧妙地糅合了现实与虚幻，展现出一个瑰丽的想象世界，成为20世纪重要的经典文学巨著之一。1982年加西亚·马尔克斯获得诺贝尔文学奖，奠定世界级文学大师的地位，很大程度上乃是凭借《百年孤独》的巨大影响。');
INSERT INTO `product` VALUES ('8', '中国科幻基石丛书·三体（套装1-3册）', '3', '/yimaiwang/images/product/12/3/3399e979-6013-4fb5-8537-208bf7e597bf.jpg', '67.2', '30', '出版社： 重庆出版社 ISBN：11757834版次：1商品编码：11757834包装：平装丛书名： 中国科幻基石丛书 开本：32开出版时间：2010-11-01用纸：胶版纸套装数量：3\r\n内容简介\r\n本套装包括《三体》、《三体2：黑暗森林》、《三体3：死神永生》3册。\r\n　　《三体》\r\n　　作者试图讲述一部在光年尺度上重新演绎的中国现代史，讲述一个文明二百次毁灭与重生的传奇。小说《三体》与三体问题有关，其中描述了一种在半人马座三星生存的三体人及其三体文明。同时《三体》也是小说中的一个模拟三体文明在一个有三颗太阳的星系中挣扎生存并发展的网络游戏，应该是由希望三体文明降临地球介入人类文明的三体组织开发的。\r\n\r\n　　《三体2：黑暗森林》\r\n　　讲述的是光年尺度下的生存推理。在三体人准备侵略地球的这段时间里，人类当然不会坐以待毙，利用三体人思维透明的致命缺陷，制订了神秘莫测的“面壁计划”，精选出四位“面壁者”，希望以此展开对三体人的反击。\r\n\r\n　　《三体3:死神永生》\r\n　　与三体文明的战争使人类首次看到了宇宙黑暗的真相，地球文明像一个恐惧的孩子，熄灭了寻友的篝火，在暗夜中发抖。自以为历经沧桑，其实刚刚蹒跚学步；自以为悟出了生存竞争的秘密，其实还远没有竞争的资格。使两个文明命悬一线的黑暗森林打击，不过是宇宙战场上的一个微不足道的插曲，一个在战场上乱跑的无知孩童被堑壕中的狙击手射杀，仅此而已。真正的星际战争没人见过，也不可能见到。因为战争的方式和武器已经远超出人类的想象，目睹战场之日，就是灭亡之时。\r\n　　人类没有想到，面对这巨大的存在，从社会学的结论，却可以推导出宇宙学的结果。宇宙的田园时代已经远去，那时，万物的之美曾昙花一现，现在已经变成任何大脑和智慧体都无法做出的梦，变成游吟诗人飘渺的残歌；宇宙的物竞天择已到了惨烈的时刻，在亿万光年暗无天日的战场上，深渊底层的毁灭力量被唤醒，太空变成了死神广阔的披风。\r\n　　太阳系中的人们永远不会知道这一切，面对真相的，只有两双眼睛。');
INSERT INTO `product` VALUES ('9', '平凡的世界（套装共3册）', '3', '/yimaiwang/images/product/7/7/bf3469a7-fd45-4772-a7f0-1fb85c1d9b1c.jpg', '49.4', '290', '出版社： 北京十月文艺出版社 ISBN：9787530212004版次：1商品编码：10924046品牌：新经典包装：软精装开本：32开出版时间：2012-03-01用纸：胶版纸页数：1264套装数量：3正文语种：中文\r\n内容简介\r\n《平凡的世界（套装共3册）》是一部现实主义小说，也是小说化的家族史。作家高度浓缩了中国西北农村的历史变迁过程，作品达到了思想性与艺术性的高度统一，特别是主人公面对困境艰苦奋斗的精神，对今天的大学生朋友仍有启迪。\r\n　　这是一部全景式地表现中国当代城乡社会生活的长篇小说。全书共三部。作者在近十年问广阔背景上，通过复杂的矛盾纠葛，刻划了社会各阶层众多普通人的形象。劳动与爱情，挫折与追求，痛苦与欢乐，日常生活与巨大社会冲突，纷繁地交织在一起，深刻地展示了普通人在大时代历史进程中所走过的艰难曲折的道路。');
INSERT INTO `product` VALUES ('10', '中华经典名著·全本全注全译丛书：论语、大学、中庸', '3', '/yimaiwang/images/product/1/9/a00ba6e3-6c05-4ca0-8002-9ce626df9d95.jpg', '19.5', '10', '出版社： 中华书局 ISBN：9787101107241 版次：2商品编码：11631181品牌：中华书局包装：精装丛书名： 中华经典名著·全本全注全译丛书 开本：32开出版时间：2015-02-01用纸：胶版纸页数：372 套装数量：1字数：200000 正文语种：中文\r\n内容简介\r\n　　《论语》是儒家的语录体著作，用言谈的原态方式记录了孔子的思想，是我们了解和研究孔子思想及儒学理论最基本也是可靠的文献。《大学》和《中庸》是儒家经典中具系统性的两种理论著作。《大学》是“内圣”与“外王”高度统一的政治理论，也就是以“德治”为指导思想的政治哲学；而《中庸》则是协调各种关系以创建和谐社会的人生学说，是儒家论述人生修养境界的一部道德哲学专著。这三部书再加上《孟子》，合称为“四书”，是元、明、清时期科举命题的经典和士人重要的必读之书，在儒学发展史上具有重要的作用和影响。');
INSERT INTO `product` VALUES ('11', '海信电视LED75XT910G3DU 超高清4K 75寸大屏幕液晶3D智能电视', '4', '/yimaiwang/images/product/9/11/cdf8fbbc-0599-41bf-97d5-f727f74616b5.png', '17988', '11', 'CCC证书编号: 2015010808762761净重(不含底座): 80kg净重(含底座): 100kg品牌: Hisense/海信屏幕尺寸: 75英寸毛重: 100kg采购地: 中国大陆最佳观看距离: 4.8m(含)-7m(不含)附加功能: 地面数字信号接收 SMART TV 数字一体机 USB媒体播放 WIFI 互联网电视 网络高清播放 网络在线电影 自动背光调节套餐类型: 官方标配3D类型: 偏光式3D售后服务: 全国联保 店铺三包同城服务: 同城卖家送货上门网络连接方式: 全部支持\r\n');
INSERT INTO `product` VALUES ('12', 'TCL L55H9600A-CUD 55英寸液晶平板电视 4K极清曲面智能网络3D', '4', '/yimaiwang/images/product/10/10/9153760d-4e82-48f4-8d82-c5974381c8f6.jpg', '7999', '112', 'CCC证书编号: 2015010808760035产品名称: TCL L55H9600A-CUD上市时间: 2014-12净重(不含底座): 19.1kg净重(含底座): 21.0kg包装尺寸: 1435x430x910mm含边框整屏尺寸: 1240x116x722mm品牌: TCLTCL LED型号: L55H9600A-CUD堆码层数极限: 3层屏幕尺寸: 55英寸毛重: 31.0kg电视形态: 曲面采购地: 中国大陆最佳观看距离: 3.5-5.0m视频显示格式: 2160p分辨率: 3840x2160HDMI接口数量: 2个面板类型: VA背光灯类型: LED发光二极管屏幕比例: 16:9附加功能: 地面数字信号接收 SMART TV 数字一体机 USB媒体播放 WIFI 互联网电视 网络高清播放 网络在线电影 自动背光调节颜色分类: 黑色套餐类型: 官方标配3D类型: 主动快门式3d能效等级: 三级售后服务: 全国联保接口类型: AV HDMI RF射频接口 VGA 色差分量接口 USB网络连接方式: 全部支持操作系统: 安卓亮度: 800cd/m^2标称对比度: 4000:1刷屏率: 120Hz扫描方式: 逐行扫描接收制式: PAL NTSC扬声器数量: 2个主机尺寸（不含底座）mm: 1240×116×722电视类型: LED电视');
INSERT INTO `product` VALUES ('13', 'Haier/海尔 BCD-557WDGSU1/BCD-517WDGSU1电冰箱干湿分储变频无霜', '4', '/yimaiwang/images/product/0/3/de50676e-b9f8-4fdd-8089-0dd00fc17ca2.jpg', '8999', '86', '产品名称: Haier/海尔 BCD-557WDGSU1上市时间: 2016-10冰箱冰柜品牌: Haier/海尔海尔冰箱型号: BCD-557WDGSU1冷冻室容积: 187L冷藏室容积: 337L净重: 136kg包装尺寸: 905x755x2010mm噪声: 35dB堆码层数极限: 1层尺寸: 830x669x1900mm总容量: 557L总容量范围: 501-600升是否变频: 变频智能类型: 不支持智能最大容积: 557L毛重: 147kg耗电量: 0.79Kwh/24h能效备案号: 201608-1-1-000000000002采购地: 中国大陆冰箱冷柜机型: 冷藏冷冻冰箱制冷方式: 风冷箱门结构: 多门式面板类型: 钢化玻璃面板能效等级: 一级售后服务: 全国联保同城服务: 同城卖家送货上门颜色分类: BCD-557WDGSU1 BCD-517WDGSU1 制冷控制系统: 电脑温控');
INSERT INTO `product` VALUES ('14', 'Gree/格力 KFR-23GW/(23570)Ga-3 格力空调Q畅1匹定频挂机壁挂式', '4', '/yimaiwang/images/product/7/10/c6376dc4-60a7-4f47-98ab-ff0117e41ab5.jpg', '2199', '46', '证书编号：2013010703633594证书状态：有效申请人名称：珠海格力电器股份有限公司制造商名称：珠海格力电器股份有限公司产品名称：分体热泵型挂壁式房间空调器 分体冷风型挂壁式房间空调器3C产品型号：见附件产品名称：Gree/格力 KFR-23GW/(...格力空调型号: KFR-23GW/(23570)Ga-3空调类型: 壁挂式冷暖类型: 冷暖电辅空调功率: 小1匹适用面积: 8-13㎡工作方式: 定速能效等级: 三级');
INSERT INTO `product` VALUES ('15', 'Haier/海尔 EG8014HB39GU1 8公斤变频全自动家用烘干滚筒洗衣机', '4', '/yimaiwang/images/product/1/7/52971893-9a37-4ba8-bbe3-c23a5a3f75fc.jpg', '3899', '55', '证书编号：2015010705817319证书状态：有效申请人名称：青岛海尔滚筒洗衣机有限公司制造商名称：青岛海尔滚筒洗衣机有限公司产品名称：滚筒洗干一体全自动洗衣机3C产品型号：XQG100-HBX14636, XQG100-HBX12736U1 额定洗涤/脱水容量:10.0k...产品名称：Haier/海尔 EG8014HB39GU...洗衣机品牌: Haier/海尔海尔洗衣机型号: EG8014HB39GU1 产品类型: 洗烘一体机使用方式: 全自动洗衣程序: 羽绒服洗、羊毛洗、混合洗能效等级: 一级电机类型: 变频电机');
INSERT INTO `product` VALUES ('16', 'Midea/美的 MB-WFZ4016XM智能Wifi电饭煲4L家用厨房电器小家电', '5', '/yimaiwang/images/product/1/0/499f643e-4882-41a7-b725-27d113f81ca8.jpg', '499', '1000', 'CCC证书编号: 2015010718793155产品名称: Midea/美的 MB-WFZ4016XM内胆厚度: 2.5mm品牌: Midea/美的型号: MB-WFZ4016XM容量: 4L智能类型: 阿里小智能效等级: 三级采购地: 中国大陆容量: 4L控制方式: 微电脑式电饭煲多功能: 柴火饭,煮粥,杂粮饭,煲汤,热饭,蒸煮,WIFI,保温 预约 煮饭内胆材质: 焖香鼎釜功率: 601W(含)-800W(含)售后服务: 全国联保形状: 方形加热方式: 三维立体加热液晶显示: 有适用人数: 4-8人');
INSERT INTO `product` VALUES ('17', '鲜榨果汁机原汁机家用电动水果汁机炸扎窄渣汁分离小家电厨房电器', '5', '/yimaiwang/images/product/7/12/d12ef26a-161b-47ec-a22d-49e49806bd3e.png', '139', '458', 'CCC证书编号: 2014010713715322功率: 400W品牌: other/其他容量: 0.5L转速: 18500转/分钟采购地: 中国大陆颜色分类: 银色 金色 红色 绿色功率: 201W(含)-500W(含)一次性最大出汁量: 401mL(含)-600mL(含)果肉渣滓盒容量: 1.001L(含)-1.5L(含)加料口形状: 圆形榨汁机附加功能: 榨汁机身材质: 不锈钢');
INSERT INTO `product` VALUES ('18', '家用五金工具套装 电工维修组合手动工具箱带组套多功能冲击电钻', '6', '/yimaiwang/images/product/6/0/a66dae3b-006f-463a-9828-6e87f97fabe6.jpg', '108', '1154', '品牌: 锐博/Reboo颜色分类: 铁质+经典全能套装 铁质+经典全能套装+切磨组合 自锁+经典全能套装 自锁+经典全能套装+切磨组合 铁质+★王者全能套装 铁质+★王者全能套装+切磨组合 自锁+★王者全能套装 自锁+★王者全能套装+切磨组合 经典全能套装（无电钻/手柄） ★王者全能套装（无电钻/手柄）件数: 51件(含)-60件(含)');
INSERT INTO `product` VALUES ('19', '拓进家用电钻工具套装多功能五金工具箱电工维修组合工具组套包', '6', '/yimaiwang/images/product/15/14/ce8b06c5-f281-46ef-8217-fd521a0c70cf.jpg', '252', '233', '品牌: TOOLKING/拓进型号: 112202颜色分类: 精品套装（63件）送剥线钳 豪华套装（51件套）送剥线钳（预售款：1.5号出） 标准套装(26件)送螺丝批两把+刀片 布包套装（11件）送刀片 经济套装（18件）送螺丝批两把+刀片 机修套装（67件）送剥线钳 高档套装（56件)送剪刀件数: 81件(含)-100件(不含)');
INSERT INTO `product` VALUES ('20', 'SUPOR/苏泊尔 SDHCB9E30-210电磁炉特价家用触摸屏火锅电池炉正品', '5', '/yimaiwang/images/product/15/4/abfa6b07-e1e9-492e-a8bd-22551ecf2a9a.jpg', '473', '552', 'CCC证书编号: 2016010711835282产品名称: SUPOR/苏泊尔 SDHCB9E30-210功率: 2100w智能类型: 不支持智能电磁炉品牌: SUPOR/苏泊尔型号: SDHCB9E30-210货号: SDHCB9E30-210采购地: 中国大陆颜色分类: 黑色电磁炉炉头: 1个功能: 爆炒 炒菜 炖奶 蒸煮 煮粥 煲汤 火锅 烧水 煎炸 定温 定时 文火煲 武火电磁炉面板类型: 黑色微晶面板功率: 1000W以下售后服务: 全国联保操作方式: 整版滑动触摸能效等级: 三级是否有预约功能: 有是否防水: 是');
INSERT INTO `product` VALUES ('21', '4K曲面智能网络55 60 65 70 75 80 85 90 95 100寸LED液晶电视机', '4', '/yimaiwang/images/product/15/7/e10d41f2-0204-4778-8cd6-4ca64ce33466.jpg', '5865', '468', 'CCC证书编号: 2011010808519394上市时间: 2017-01净重(不含底座): 45kg品牌: FamilySee型号: SJL65QB电视形态: 平板采购地: 中国大陆最佳观看距离: 7.0米以上(80英寸)视频显示格式: 2160p分辨率: 3840x2160HDMI接口数量: 2个面板类型: IPS背光灯类型: LED发光二极管屏幕比例: 16:9附加功能: 地面数字信号接收 SMART TV 数字一体机 USB媒体播放 WIFI 互联网电视 网络高清播放 网络在线电影 自动背光调节颜色分类: 75寸4K平面网络版 80寸4K平面网络版 90寸4K平面网络版 95寸4K平面网络版 85寸4K平面网络版 80寸平面3D网络版 65寸4K平面网络版 42寸平面3D网络版 55寸平面3D网络版 60寸4K平面网络版 55寸4K平面网络版 55寸曲面3D网络版 60寸曲面3D网络版 60寸平面3D网络版 110寸4K平面网络版 70寸平面3D网络版 70寸4K平面网络版 75寸4K曲面网络版 60寸4K曲面网络版 55寸4K曲面网络版 65寸4K曲面网络版 100寸4K平面网络版3D类型: 偏光式3D能效等级: 一级售后服务: 全国联保接口类型: AV HDMI S端子接口 RF射频接口 VGA 耳机接口 其他/other 色差分量接口 LAN端子 USB网络连接方式: 全部支持操作系统: 安卓亮度: 800cd/m^2标称对比度: 100000:1刷屏率: 240Hz扫描方式: 逐行扫描接收制式: PAL\\NTSC\\SECAM扬声器数量: 2个电视类型: OLED电视');
INSERT INTO `product` VALUES ('22', '大功率迷你双电机油烟机侧吸式小尺寸抽油烟机小型家用老式特价', '4', '/yimaiwang/images/product/12/0/f7aeb48f-52c2-4acd-b1d9-4e6d239cf6d0.jpg', '1688', '98', '证书编号：2014010716714143证书状态：有效申请人名称：嵊州市思品厨卫电器有限公司制造商名称：嵊州市思品厨卫电器有限公司产品名称：吸油烟机3C产品型号：CXW-218-T1, CXW-218-T2, CXW-218-T6, CXW-218-T7, CX...上市时间: 2015-03产地: 中国大陆净重: 16kg包装尺寸: 755*505*380mm噪声: 54dB堆码层数极限: 4层尺寸: 700*470*310mm按键类型: 机械式控制面板材质: 不锈钢智能类型: 其他智能机身材质: 不锈钢毛重: 20kg油烟机品牌: 思品型号: CXW-218-808-MINI油烟机排风量: 16立方米/分钟颜色分类: 全国联保 苏宁免费安装（双电机款） 全国联保 苏宁免费安装（双电机玻璃款）烟机安装位置: 侧吸式拢烟罩结构: 深罩型售后服务: 全国联保同城服务: 同城上门安装油烟机种类: 侧吸');
INSERT INTO `product` VALUES ('23', '27寸迷你电脑LOL游戏办公电脑台式电脑全套台式机组装电脑整机', '7', '/yimaiwang/images/product/1/4/b9b064ab-11ed-4e0d-a460-e5d1c93c3f83.jpg', '4550.4', '55', 'CPU主频: 3.0GHz及以上CPU型号: X4 760CPU核心数: 四核心CPU类型: AMD NPU主板品牌: MAXSUN/铭瑄主板结构: ATX内存品牌: KingSton/金士顿内存类型: DDR3内存频率: 1600MHz品牌: 见描述套餐类型: 套餐一 套餐二散热方式: 散热片散热设备品牌: AMD显卡品牌: XFX/讯景显存位宽: 128bit显存类型: GDDR5机箱品牌: 寒霜机箱结构: ATX电源80 PLUS认证: 金牌电源品牌: 奋斗者硬盘品牌: WD/西部数据硬盘类型: 机械硬盘配置类型: 疯狂游戏型适用品牌: AMD兼容机AMD型号: 其他/other主板芯片组类型: AMD A68内存容量: 8GB显卡类型: 独立显卡独立显卡型号: 其他/other显存容量: 2GB硬盘容量: 500GB光驱类型: 无光驱电源功率: 其他/other成色: 全新显卡系列: R7 350显示器尺寸: 24英寸');
INSERT INTO `product` VALUES ('24', '子玥 Intel六核/2G独显/8G台式组装电脑主机游戏DIY整机全套', '7', '/yimaiwang/images/product/2/9/02191d61-535c-4349-890a-dbaf83e77fac.jpg', '2999.9', '88', 'CPU主频: 2.4GHz(含)-2.8GHz(不含)CPU型号: 5420CPU核心数: 四核心CPU类型: 其他主板品牌: 科脑主板结构: E-ATX内存品牌: 镁光内存类型: DDR3内存频率: 1600MHz办公用途: 美工电脑品牌: Edifier/漫步者套餐类型: 套餐一 套餐二 套餐三 套餐四散热方式: 风冷散热设备品牌: 超频三显卡品牌: XFX/讯景显存位宽: 128bit显存类型: GDDR5最大内存容量: 16GB机箱品牌: 科迪亚机箱结构: EATX电源80 PLUS认证: 白牌电源品牌: 欧博美硬盘品牌: Seagate/希捷硬盘类型: 机械硬盘配置类型: 经济实惠型适用品牌: INTEL兼容机INTEL型号: 其他/other主板芯片组类型: Intel P45内存容量: 4GB显卡类型: 独立显卡独立显卡型号: 其他/other显存容量: 2GB硬盘容量: 500GB光驱类型: 无光驱电源功率: 其他/other成色: 全新同城服务: 同城卖家送货上门显卡系列: R7 240显示器尺寸: 22英寸');
INSERT INTO `product` VALUES ('25', 'Midea/美的 F80-30W7(HD)电热水器储水式家用洗澡80升即热速热60', '4', '/yimaiwang/images/product/3/12/4d1a811c-95e0-44f2-be22-f7ce67c2f7f5.jpg', '1599.99', '154', '证书编号：2011010706464158证书状态：有效申请人名称：广东美的厨卫电器制造有限公司制造商名称：广东美的厨卫电器制造有限公司产品名称：密闭型储水式电热水器3C产品型号：见附件产品名称：Midea/美的 F80-30W7(H...品牌: Midea/美的热水器美的型号: F80-30W7(HD)控制方式: 遥控式款式: 横式能效等级: 一级');
INSERT INTO `product` VALUES ('26', 'Lenovo/联想 YOGA710 -14ISK 超极本 超薄笔记本电脑PC平板二合一', '7', '/yimaiwang/images/product/15/12/80d9a76f-e175-4e3e-accc-0f56db0897a8.jpg', '6299.99', '584', '证书编号：2016010902852211证书状态：有效产品名称：便携式计算机产品名称：Lenovo/联想 YOGA710 -1...品牌: Lenovo/联想型号: -14ISK屏幕尺寸: 14英寸CPU: 酷睿i5-7200U显卡类型: NVIDIA GeForce GT940MX显存容量: 2GB机械硬盘容量: 无机械硬盘内存容量: 4GB操作系统: windows 10');
INSERT INTO `product` VALUES ('27', 'Apple/苹果 Watch Series 2 苹果智能手表 iWatch watch2', '8', '/yimaiwang/images/product/8/7/343ccd3d-085d-4291-a4e3-0da993e2dcb4.jpg', '3128.99', '199', '表壳尺寸: 38mm 42mm品牌: Apple/苹果型号: Apple Watch Series 2通讯类型: 不可插卡表带尺寸: 适合130-200毫米腕围 适合140-210毫米腕围颜色分类: 深空灰色铝金属表壳搭配黑色运动型表带 银色铝金属表壳搭配白色运动型表带 玫瑰金色铝金属表壳搭配粉砂色运动型表带 金色铝金属表壳搭配砖青色运动型表带 银色铝金属表壳搭配珍珠色精织尼龙表带 深空灰色铝金属表壳搭配黑色精织尼龙表带 深空灰色铝金属表壳搭配黑配荧光黄色Nike运动型表带 深空灰色铝金属表壳搭配黑配冷灰色Nike运动表带 银色铝金属表壳搭配冷银配荧光黄色 Nike 运动表带 银色铝金属表壳搭配冷银配白色 Nike 运动表带 金色铝金属表壳搭配可可色运动型表带 玫瑰金色铝金属表壳搭配午夜蓝色运动型表带 玫瑰金色铝金属表壳搭配亮橙配灰色精织尼龙表带系列: 官方标配连接方式: 蓝牙连接表壳材质: 铝金属表壳，不锈钢表壳表带材质: 运动型表带，精织尼龙表带，不锈钢表带，皮革表带表盘形状: 方形兼容平台: iOS功能: 心率监测 蓝牙通话 计步 防水无线距离: 5m(含)-10m(含)');
INSERT INTO `product` VALUES ('28', '乐心智能手环 蓝牙运动设备华为手表跑步计步器健康防水小米2苹果', '8', '/yimaiwang/images/product/15/15/a40fad0c-a02a-4da7-a6c7-9f3e1ec11f91.jpg', '99', '111', '兼容平台: ANDROID iOS功能: 睡眠监测 计步 防水品牌: Life Sense/乐心型号: Mambo颜色分类: 文字或字母定制版 私人定制版 黑色光面版 黑色波点版 蓝色 玫红色适用对象: android平台 苹果iOS平台无线距离: 5m(含)-10m(含)');
INSERT INTO `product` VALUES ('29', '真八核VR虚拟现实3D眼镜一体机成人头戴式高清影院游戏资源头盔', '8', '/yimaiwang/images/product/0/5/5d402f25-092c-4918-8532-3653d95a5eb5.jpg', '899', '15', '兼容平台: ANDROID Blackberry MIUI Symbian WindowsMobile iOS 百度云OS 阿里巴巴云OS品牌: newjobs型号: ak911颜色分类: 黑白色');
INSERT INTO `product` VALUES ('30', '达尔优牧马人3代升级版六色背光EM915电竞游戏鼠标 自定义 宏鼠标', '9', '/yimaiwang/images/product/10/3/da77707f-ef01-468c-91b5-0ad5f1ba0c03.jpg', '188', '247', '产品名称：达尔优 牧马人升级版包装体积: 0.1品牌: 达尔优型号: 牧马人升级版套餐类型: 官方标配毛重: 0.35颜色分类: 《二代黑色裂纹版》 牧马人升级版白色 牧马人WCG 牧马人三代黑色版 牧马人三代白色版工作方式: 光电接口类型: USB按键数: 8个光学分辨率: 4000dpi是否支持人体工程学: 支持成色: 全新售后服务: 全国联保');
INSERT INTO `product` VALUES ('31', 'Technology/新盟 X5游戏耳机头戴式usb台式电脑耳麦发光带话筒cf', '9', '/yimaiwang/images/product/11/2/b0d3dd30-dd29-4109-8b44-10c282acfecc.jpg', '89', '355', '产品名称：Technology/新盟 X5兼容平台: ANDROID Windows Phone iOS套餐类型: 官方标配灵敏度: 119dB/mW适用音乐类型: 摇滚金属重低音类型阻抗: 30Ω频响范围: 20-20Hz颜色分类: 白色 黑色 白色7.1版 黑色7.1版佩戴方式: 头戴护耳式耳机类型: 有线有无麦克风: 带麦耳机售后服务: 全国联保插头直径: 3.5mm耳机插头类型: 直插型耳机输出音源: PC电脑缆线长度: 2.5米耳机类别: 游戏影音耳机品牌: Technology/新盟型号: X5');
INSERT INTO `product` VALUES ('32', '北通阿修罗TE版无线游戏手柄pc电脑360安卓手机街篮steam乐视电视', '9', '/yimaiwang/images/product/14/8/f19cf933-317b-4b7c-947e-64f8e06994f8.jpg', '155', '66', '产品名称：BETOP/北通 阿修罗TE品牌: BETOP/北通北通手柄: 阿修罗TE有无线: 无线适用对象: android平台颜色分类: 炫光黑（出厂标配）送手柄绒布袋 炫光白（出厂标配）送手柄绒布袋 炫光黑 送手柄绒布袋+品牌OTG线 炫光白 送手柄绒布袋+品牌OTG线 炫光黑 送手柄绒布袋+1米延长线 炫光白 送手柄绒布袋+1米延长线 炫光黑 送手柄绒布袋+黑色硅胶套 炫光白 送手柄绒布袋+白色硅胶套 炫光黑 送手柄绒布袋+蓝色硅胶套 炫光白 送手柄绒布袋+蓝色硅胶套 炫光黑 送手柄绒布袋+白色硅胶套 炫光白 送手柄绒布袋+黑色硅胶套 炫光黑 送手柄袋+白色支架+OTG线 炫光白 送手柄袋+手柄支架+OTG线 炫光黑 炫光白 炫光黑 送手柄袋+手柄支架+OTG线手柄特性: 震动接口类型: USB');
INSERT INTO `product` VALUES ('33', '狼途ZL300可换轴机械键盘黑轴青轴茶轴红轴绿轴电脑网吧游戏有线', '9', '/yimaiwang/images/product/15/14/674b5409-4b36-442b-8549-f36a1688fbb1.jpg', '156', '474', '产品名称：狼途 ZL300第三代自由换轴...包装体积: 48.5*19*5cm品牌: 狼途型号: ZL300第三代自由换轴版套餐类型: 套餐一 套餐三 套餐二 套餐五 套餐四 官方标配是否机械键盘: 是毛重: 1161g颜色分类: 第三代CIY自换轴版（白色）青轴104键 第三代CIY自换轴版（黑色）黑轴104键是否支持即插即用: 支持连接方式: 有线是否有多媒体功能键: 无接口类型: USB是否支持人体工程学: 支持有无手托: 无成色: 全新售后服务: 全国联保');
INSERT INTO `product` VALUES ('34', '昕朴2016冬季新款加厚外套A字韩版连帽显瘦羽绒服女中长款大毛领', '10', '/yimaiwang/images/product/11/4/aeb3e286-ffac-4e80-bb98-f6321d38b9a3.jpg', '359', '129', '充绒量: 100g(含)-150g(不含)含绒量: 90%材质成分: 聚酯纤维100%销售渠道类型: 纯电商(只在线上销售)品牌: 昕朴货号: XP0320服装版型: 斗篷型厚薄: 加厚风格: 通勤通勤: 韩版衣长: 中长款袖长: 长袖领子: 连帽袖型: 常规衣门襟: 拉链图案: 纯色流行元素/工艺: 带毛领 口袋填充物: 白鸭绒适用年龄: 25-29周岁上市年份季节: 2016年秋季颜色分类: 0320A版大毛领黑色 0320A版大毛领灰色尺码: S M L XL XXL XXXL');
INSERT INTO `product` VALUES ('35', '凡迪保罗秋冬厚款羊毛风衣男 围巾领可拆卸中长款修身英伦男外套', '11', '/yimaiwang/images/product/13/10/ee82eb29-83ec-4b2d-abe0-562a95fe040b.jpg', '354', '366', '上市年份季节: 2015年秋季材质成分: 羊毛50% 聚酯纤维49.8% 其他0.2%货号: 15A5858VD面料分类: 毛呢布品牌: Vanddy＆Paul/凡迪保罗基础风格: 商务绅士');
INSERT INTO `product` VALUES ('36', '【下单减500】Apple/苹果 iPhone 7 Plus 32G 全网通4G智能手机', '12', '/yimaiwang/images/product/11/5/4c6465e7-a8d9-40f3-bdff-bdc6e44a7da2.jpg', '6388', '21', '证书编号：2016011606893750证书状态：有效产品名称：TD-LTE 数字移动电话机产品名称：Apple/苹果 iPhone 7 Plu...Apple型号: iPhone 7 Plus机身颜色: 黑色 金色 亮黑色 玫瑰金色 银色运行内存RAM: 不详存储容量: 32GB 128GB 256GB网络模式: 蜂窝网络和无线连接');
INSERT INTO `product` VALUES ('37', '【套餐不加价│12期免息】Huawei/华为 P9 64G全网通4G智能手机', '13', '/yimaiwang/images/product/5/13/8bb9f43c-22ef-4671-acf3-62a8a91f72ea.jpg', '3388', '100', '证书编号：2016011606844086证书状态：有效申请人名称：华为技术有限公司制造商名称：华为技术有限公司产品名称：TD-LTE数字移动电话机3C产品型号：EVA-AL10（开关电源适配器：HW-050200C01 输出：5VDC 2A）产品名称：Huawei/华为 P9全网通CPU型号: 其他华为型号: P9全网通机身颜色: 玫瑰金 陶瓷白 金色 玛瑙红 托帕蓝运行内存RAM: 4GB存储容量: 64GB网络模式: 双卡双待双通电池容量: 3000mAh');
INSERT INTO `product` VALUES ('38', '【下单立减600】Samsung/三星Galaxy S7edge G9350全网通4G手机', '14', '/yimaiwang/images/product/4/0/906333e4-1954-4cd7-beee-8841bc0a8b63.jpg', '5988', '8', '证书编号：2016011606841421证书状态：有效申请人名称：惠州三星电子有限公司制造商名称：惠州三星电子有限公司产品名称：TD-LTE数字移动电话机3C产品型号：SM-G9350（旅行充电器：EP-TA20CBC 输出: 9.0Vdc/1.67A 或 5.0Vd...产品名称：Samsung/三星 Galaxy S7 ...CPU型号: 其他三星型号: Galaxy S7 Edge SM-G9350机身颜色: 铂光金 星钻黑运行内存RAM: 4GB存储容量: 32GB 64GB网络模式: 双卡多模电池容量: 3600mAh');

-- ----------------------------
-- Table structure for product_one
-- ----------------------------
DROP TABLE IF EXISTS `product_one`;
CREATE TABLE `product_one` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product_one
-- ----------------------------
INSERT INTO `product_one` VALUES ('1', '图书');
INSERT INTO `product_one` VALUES ('2', '家用电器');
INSERT INTO `product_one` VALUES ('3', '电脑、办公');
INSERT INTO `product_one` VALUES ('4', '服装');
INSERT INTO `product_one` VALUES ('15', '手机');

-- ----------------------------
-- Table structure for product_two
-- ----------------------------
DROP TABLE IF EXISTS `product_two`;
CREATE TABLE `product_two` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `p_parentid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `oneid` (`p_parentid`),
  CONSTRAINT `oneid` FOREIGN KEY (`p_parentid`) REFERENCES `product_one` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product_two
-- ----------------------------
INSERT INTO `product_two` VALUES ('1', '少儿图书', '1');
INSERT INTO `product_two` VALUES ('3', '青年图书', '1');
INSERT INTO `product_two` VALUES ('4', '大家电', '2');
INSERT INTO `product_two` VALUES ('5', '厨房小电', '2');
INSERT INTO `product_two` VALUES ('6', '五金家装', '2');
INSERT INTO `product_two` VALUES ('7', '电脑整机', '3');
INSERT INTO `product_two` VALUES ('8', '智能数码', '3');
INSERT INTO `product_two` VALUES ('9', '游戏设配', '3');
INSERT INTO `product_two` VALUES ('10', '女装', '4');
INSERT INTO `product_two` VALUES ('11', '男装', '4');
INSERT INTO `product_two` VALUES ('12', '苹果', '15');
INSERT INTO `product_two` VALUES ('13', '华为', '15');
INSERT INTO `product_two` VALUES ('14', '三星', '15');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `role` int(11) NOT NULL,
  `registtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `state` int(11) NOT NULL,
  `activecode` varchar(100) DEFAULT NULL,
  `sex` varchar(5) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('2', 'admin', '202cb962ac59075b964b07152d234b70', 'admin', 'service@hp.com', '1', '2017-02-02 15:57:24', '1', 'dkjfldsjflksdjf', '男', '', '');
INSERT INTO `users` VALUES ('3', '李小波', '202cb962ac59075b964b07152d234b70', '小波12', '15111397674@163.com', '0', '2017-02-01 22:55:43', '1', null, '男', '15111397674', '白地市镇');
INSERT INTO `users` VALUES ('6', '1994', '81dc9bdb52d04dc20036dbd8313ed055', '小小博', 'aaa@hp.com', '0', '2017-01-27 10:04:19', '1', 'c5111197-8cbc-4a7b-b04d-a21756c30307', '男', '15111397674', '湖南省衡阳市祁东县风石堰镇鲜鱼市场');
