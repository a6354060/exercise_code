/**
 * @author lycheng
 */


//判断字符串是否为数字
var isIntNumber = function(String){
	var Letters = "1234567890";
	var i;   
	var c;    
	for( i = 0; i < String.length; i ++ )   
	{     
		c = String.charAt( i );   
		if (Letters.indexOf( c ) < 0)   
			return false;   
	}
	return true;  		
};
// 判断字符串是否符合邮件地址格式
var isEmail = function(strEmail)
{
	if (strEmail.search(/^([a-zA-Z0-9]+[-|_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[-|_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/) != -1)   
		return true;   
	else   
		return false;  		
};

var isMobile = function(mobile) {
	return (/^1[3|4|5|8|7][0-9]\d{8}$/.test(mobile));
};

/**
 * 判断包含多少个字节
 */
function getBytesCount(str) { 
	if (str == null){ 
		return 0; 
	}else{ 
		var enterLen = 0;
		if(navigator.userAgent.indexOf("WebKit")>0){
			enterLen = str.length-str.replace(/\n/g, "").length;
		}
		return (str.length + str.replace(/[\u0000-\u00ff]/g, "").length + enterLen);
		// return  str.length + str.replace(/[^\u0080-\u07FF]/g, "").length + str.replace(/[^\u0800-\uFFFF]/g, "").length*2 + enterLen;
	} 
}

//获得图片验证码
function changePhoneJudge() {
	$(".yzmimg").attr("src", __base_url + "captcha/captcha.php?" + Math.random());
	$("#yanzhengma").val("");
}
/**
 * 截取指定字节数的字符串
 */
function getStrBytesCount(str,account)
{
  var bytesCount = 0,thisByteCount=0;
  if (str != null)
  {
    for (var i = 0; i < str.length; i++){
		var c = str.charAt(i);
	 	//0000 - 007F 0xxxxxxx
		// 0080 - 07FF 110xxxxx 10xxxxxx
		// 0800 - FFFF 1110xxxx 10xxxxxx 10xxxxxx
		// if(/^[\u0000-\u007F]$/.test(c)){
		// 	thisByteCount= 1;
		// }else if(/^[\u0080-\u07FF]$/.test(c)){
		// 	thisByteCount= 2;
		// }else if(/^[\u0800-\uFFFF]$/.test(c)){
		// 	thisByteCount= 3;
		// }
		if (/^[\u0000-\u00ff]$/.test(c)){
			if(navigator.userAgent.indexOf("WebKit")>0 && c=='\n'){
				thisByteCount= 2;
			}else{
				thisByteCount= 1;
			}
		}else{
			thisByteCount= 2;
		}
		if(thisByteCount+bytesCount > account){
			bytesCount=i;
			break;	      		
		}else{
			bytesCount += thisByteCount;
		}
    }
     return str.substr(0, bytesCount);
  }
	return "";
 }
