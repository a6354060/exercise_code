var judgeCallback={
	//判断邮箱是否已经被注册
	judgeEmail:function(desc,email,async){
		var textValid=true;
		jQuery.ajax({
			type : "get",
			url : __base_url+"index.php/ajax/check",
			data:{
				'email':email
			},
			async:async,
			success : function(result) {
				if(result==-1){
					//邮箱已经被注册
					desc.text("邮箱已经被注册").addClass("form_item_error").removeClass("form_item_success");
					textValid= false;
				}else{
					//textValid= true;
				}
			},
			error:function(){
				textValid= false;
			}
		});
		return textValid;
	},
	//判断验证码错误
	judgeYZM:function(desc,yzm,async){
		var textValid=true;
		jQuery.ajax({
			type : "get",
			url : __base_url+"index.php/ajax/check/verifyimage",
			data:{
				'code':yzm
			},
			async:async,
			success : function(result) {
				if(result==-1){
					//验证码错误
					desc.text("验证码不正确，请重新输入！").addClass("form_item_error").removeClass("form_item_success");
					changePhoneJudge();
					textValid= false;
				}else{
					textValid= true;
				}
			},
			error:function(){
				textValid= false;
			}
		});
		return textValid;
	},
	beforeSubmit:function(flag, formid, async){
		if(flag == 1){
			$(document.getElementsByName("password")[0]).val(rsaEncode($("#password").val()));
		}
		return true;
	}
}

var tips={
	email:{
		tip:"为方便找回密码，请输入常用的邮箱！",
		nulltip:"请输入邮箱！",
		repeattip:"邮箱已注册！",
		errortip:"邮箱格式不正确！"
	},
	username:{
		tip:"",
		nulltip:"请输入用户名！",
		repeattip:"用户名已被注册，请更换其他用户名！",
		regtip:"只能包含字母、数字和下划线！"
	},
	password:{
		nulltip:"请输入密码！",
		errortip:"密码长度为6到20之间！"
	},
	repassword:{
		tip:"",
		nulltip:"请输入重复密码！",
		errortip:"两次密码输入不一致，请重新输入！"
	},
	agreement:{
		tip:"请接受条款后注册"
	}
}


/**
 * 重置发送间隔时间
 */
var timeSecond=60;
/**
 * 指定时间间隔过去了多长时间
 */
function resetSendTime2(time){
	timeSecond=60;
	var si = setInterval(function(){
		timeSecond--;
	},1000);

	setTimeout(function(){
		clearInterval(si);
		timeSecond=0;
	}, time);
}
/**
 * 多少时间后做某事
 */
function resetSendTime(thisObj,time,callback){
	$("#resendemailtip").css("display","none");
	$("#sendemailtip").css("display","block");
	$("#djs_num").text(time/1000);
	var si = setInterval(function(){
		$("#djs_num").text($("#djs_num").text() - 1);
	},1000);

	setTimeout(function(){
		$("#resendemailtip").css("display","block");
		$("#sendemailtip").css("display","none");
		if(callback){
			callback(thisObj);
		}
		$("#sms_success_tips").remove();
		clearInterval(si);
	}, time);
}

//再次发送邮箱验证

function resendverifi(thisObj){
	//判断邮箱是否已被注册
	jQuery.ajax({
		type : "get",
		url : __base_url+"index.php/ajax/email",
		async:false,
		success : function(result) {
			if(result == 1){
				resetSendTime2(61*1000);
			} else {
				alert("发送失败，请重试！");
			}
		}
	});
}

/**
 * 60秒后的发送邮件
 */
function sendEmail(email){
	var thisObj=$(this);
	if(timeSecond>0){
		resetSendTime(thisObj,timeSecond*1000);
	}else{
		resendverifi(thisObj);
	}
}

function submitFunc(){
	if($(this).attr("_able") == "0"){
		return;
	}
	var count=0;
	var agreement = judgeAgreement($("#accept"));
	for(var id in errorArr){
		if(!errorArr[id]){
			$("#"+id).focus();
			return false;
		}
		count+=errorArr[id];
	}
	if(count<5){
		$("#email").focus();
		return false;
	}

	if(agreement==0){
		return false;
	}
	//$('#regform').submit();
	$("#submit_btn").attr("disabled","disabled");
	setTimeout(function(){
		$("#submit_btn").removeAttr("disabled");
	}, 200);
}
function register(){
	if(checkPassowrd()){
		return form_submit('regform', 'beforeSubmit');
	}
}
function checkPassowrd(){
	if($(".password-tip").hasClass("min")){
		$("#password").parents(".passworddiv").find(".info_content_tip").removeClass("form_item_success").addClass("form_item_error").text("密码强度太弱，建议大小写字母+数字+特殊字符");
		return false;
	}
	$("#password").parents(".passworddiv").find(".info_content_tip").addClass("form_item_success").removeClass("form_item_error").text("");
	return true;
}
$(function(){
	//倒计时60秒
	resetSendTime2(61000);
	//复选框
	$(".checkbg").click(function(){
		if($(this).attr("class").indexOf("checkedbg")>-1){
			$("#accept_tip").text("　").removeClass("form_item_error").addClass("form_item_success");
		}else{
			$("#accept_tip").text("请接受授权协议，谢谢！").addClass("form_item_error").removeClass("form_item_success");

		}
	});

	$("#password").on("keyup",function(){
		var str=$("#password").val();
		if(str.length>0){
			$(".password-tip").show();
		}else {
			$(".password-tip").hide();
			$(".password-tip").removeClass("min").removeClass("mid").removeClass("max");
		}
		if(str.length >=6) {
			if(/[a-zA-Z]+/.test(str) && /[0-9]+/.test(str) && /\W+\D+/.test(str)) {
				setPasswordTip("max");
			}else if(/[a-zA-Z]+/.test(str) || /[0-9]+/.test(str) || /\W+\D+/.test(str)) {
				if(/[a-zA-Z]+/.test(str) && /[0-9]+/.test(str)) {
					setPasswordTip("mid");
				}else if(/\[a-zA-Z]+/.test(str) && /\W+\D+/.test(str)) {
					setPasswordTip("mid");
				}else if(/[0-9]+/.test(str) && /\W+\D+/.test(str)) {
					setPasswordTip("mid");
				}else{
					setPasswordTip("min");
				}
			}
		}else{
			setPasswordTip("min");
		}

	});
	function setPasswordTip(type){
		if(type=="min"){
			$(".password-tip-text").text("弱");
		}else if(type=="mid"){
			$(".password-tip-text").text("中");
		}else {
			$(".password-tip-text").text("强");
		}
		$(".password-tip").removeClass("min").removeClass("mid").removeClass("max").addClass(type);
	}

	//其他方式登录
	$(".other_login").click(function(){
		var type = $(this).find("a").attr("type");
		$.cookie("otherLoginType","1",{
			"path":"/"
		});
		childWindow = window.open("default/authlogin/index?state=msp" + type,"TencentLogin","width=450,height=320,menubar=0,scrollbars=1, resizable=1,status=1,titlebar=0,toolbar=0,location=1");
	})

	//复选框
	$(".checkbg").click(function(){
		if($(this).attr("class").indexOf("checkedbg")>-1){
			$("#submitbtn").css({"background":"#1580d2"}).attr("_able","1");
		}else{
			$("#submitbtn").css({"background":"#ccc9c9"}).attr("_able","0");
		}
	});
	// $("#email").focus();
});
