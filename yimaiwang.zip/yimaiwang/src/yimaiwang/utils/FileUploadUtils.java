package yimaiwang.utils;

import java.io.File;
import java.util.UUID;

public class FileUploadUtils {
	/**
	 * 文件上传工具类
	 */

	public static String subFileName(String fileName) {
		if (fileName.contains("\\")) {
			fileName = fileName.substring(fileName.lastIndexOf("\\") + 1);
			return fileName;
		} else {

			return fileName;
		}
	}

	public static boolean isImage(String contentType) {

		if (contentType.contains("image/")) {
			return true;

		} else {
			return false;
		}

	}
	
	public static String multiFolder(String uuidname){
		 int hashCode=uuidname.hashCode();
		 // 2级目录
		 int d1=hashCode&0xf;
		 int d2=hashCode>>4&0xf; // 右移动4位
		 return "/"+d1+"/"+d2;
	}
	
	public static String getUUIDName(String name){
		   name=name.substring(name.lastIndexOf("."));
		
		  return  UUID.randomUUID().toString()+name;
		
	}
	
	// 产品ID
	public static String getProductId(){
		
		return "YP_"+Math.abs(UUID.randomUUID().toString().hashCode());
	}
	// 删除文件
	public static void deletePic(String filepath,String img){
		File flie=new File(filepath.substring(0, filepath.lastIndexOf("\\")).substring(0,(filepath.substring(0, filepath.lastIndexOf("\\")).lastIndexOf("\\"))));
		File f=new File("D:/jinkeying/yimaiwang/WebContent" + img.substring(0, img.lastIndexOf("/")).substring(0,(img.substring(0, img.lastIndexOf("/")).lastIndexOf("/"))));
		//FileUtils.deleteFile(flie);
		//FileUtils.deleteFile(f);
	}
	

}
