package yimaiwang.utils;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

/**
 * 锟斤拷锟斤拷图片锟斤拷锟斤拷图
 * 
 * @author seawind
 * 
 */
public class PicUtils {
	private String srcFile;
	private String destFile;
	private int width;
	private int height;
	private Image img;

	/**
	 * 锟斤拷锟届函锟斤拷
	 * 
	 * @param fileName
	 *            String
	 * @throws IOException
	 */
	public PicUtils(String fileName) throws IOException {
		File _file = new File(fileName); // 锟斤拷锟斤拷锟侥硷拷
		this.srcFile = fileName;
		// 锟斤拷锟斤拷锟斤拷锟揭伙拷锟�.
		int index = this.srcFile.lastIndexOf(".");
		String ext = this.srcFile.substring(index);
		this.destFile = this.srcFile.substring(0, index) + "_s" + ext;
		img = javax.imageio.ImageIO.read(_file); // 锟斤拷锟斤拷Image锟斤拷锟斤拷
		width = img.getWidth(null); // 锟矫碉拷源图锟斤拷
		height = img.getHeight(null); // 锟矫碉拷源图锟斤拷
	}

	/**
	 * 强锟斤拷压锟斤拷/锟脚达拷图片锟斤拷锟教讹拷锟侥达拷小
	 * 
	 * @param w
	 *            int 锟铰匡拷锟�
	 * @param h
	 *            int 锟铰高讹拷
	 * @throws IOException
	 */
	public void resize(int w, int h) throws IOException {
		BufferedImage _image = new BufferedImage(w, h,
				BufferedImage.TYPE_INT_RGB);
		_image.getGraphics().drawImage(img, 0, 0, w, h, null); // 锟斤拷锟斤拷锟斤拷小锟斤拷锟酵�
		FileOutputStream out = new FileOutputStream(destFile); // 锟斤拷锟斤拷锟斤拷募锟斤拷锟�
		JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
		encoder.encode(_image); // 锟斤拷JPEG锟斤拷锟斤拷
		out.close();
	}

	/**
	 * 锟斤拷锟秸固讹拷锟侥憋拷锟斤拷锟斤拷锟斤拷图片
	 * 
	 * @param t
	 *            double 锟斤拷锟斤拷
	 * @throws IOException
	 */
	public void resize(double t) throws IOException {
		int w = (int) (width * t);
		int h = (int) (height * t);
		resize(w, h);
	}

	/**
	 * 锟皆匡拷锟轿拷锟阶硷拷锟斤拷缺锟斤拷锟斤拷锟斤拷锟酵计�
	 * 
	 * @param w
	 *            int 锟铰匡拷锟�
	 * @throws IOException
	 */
	public void resizeByWidth(int w) throws IOException {
		int h = (int) (height * w / width);
		resize(w, h);
	}

	/**
	 * 锟皆高讹拷为锟斤拷准锟斤拷锟饺憋拷锟斤拷锟斤拷锟斤拷图片
	 * 
	 * @param h
	 *            int 锟铰高讹拷
	 * @throws IOException
	 */
	public void resizeByHeight(int h) throws IOException {
		int w = (int) (width * h / height);
		resize(w, h);
	}

	/**
	 * 锟斤拷锟斤拷锟斤拷锟竭讹拷锟斤拷锟狡ｏ拷锟斤拷锟斤拷锟斤拷锟侥等憋拷锟斤拷锟斤拷锟斤拷图
	 * 
	 * @param w
	 *            int 锟斤拷锟斤拷锟�
	 * @param h
	 *            int 锟斤拷锟竭讹拷
	 * @throws IOException
	 */
	public void resizeFix(int w, int h) throws IOException {
		if (width / height > w / h) {
			resizeByWidth(w);
		} else {
			resizeByHeight(h);
		}
	}

	/**
	 * 锟斤拷锟斤拷目锟斤拷锟侥硷拷锟斤拷 setDestFile
	 * 
	 * @param fileName
	 *            String 锟侥硷拷锟斤拷锟街凤拷锟斤拷
	 */
	public void setDestFile(String fileName) throws Exception {
		if (!fileName.endsWith(".jpg")) {
			throw new Exception("Dest File Must end with \".jpg\".");
		}
		destFile = fileName;
	}

	/**
	 * 锟斤拷取目锟斤拷锟侥硷拷锟斤拷 getDestFile
	 */
	public String getDestFile() {
		return destFile;
	}

	/**
	 * 锟斤拷取图片原始锟斤拷锟� getSrcWidth
	 */
	public int getSrcWidth() {
		return width;
	}

	/**
	 * 锟斤拷取图片原始锟竭讹拷 getSrcHeight
	 */
	public int getSrcHeight() {
		return height;
	}
	public static void main(String[] args) {
		// 添加自动生成小图 代码
		PicUtils picUtils = null;
		try {
			picUtils = new PicUtils("D:\\java_ee\\estore\\WebContent\\upload\\8\\13/be6dcb4c-3db5-4fa4-81d9-66c16e4faf43.jpg");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		try {
			picUtils.resize(100, 100);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}
}
