package yimaiwang.utils;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Utils {

	public static String md5(String args) {

		MessageDigest digest = null;
		try {
			digest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			throw new RuntimeException("没有MD5算法");
		}
		byte[] dig = digest.digest(args.getBytes());

		return new BigInteger(1, dig).toString(16);
	}

}
