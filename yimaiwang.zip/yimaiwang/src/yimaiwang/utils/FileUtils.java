package yimaiwang.utils;

import java.io.File;

/**
 * 文件工具类
 * 
 * @author hp
 *
 */
public class FileUtils {
	// 删除文件
	public static void deleteFile(File f1) {
		if (f1.isDirectory()) {
			File[] f = f1.listFiles();
			for (File file : f) {
				if (file.isFile()) {
					file.delete();
				}
				if (file.isDirectory()) {
					deleteDir(file);
					file.delete();
				}
			}
		} else {
			f1.delete();
		}
		f1.delete();
	}

	public static void deleteDir(File f) {
		File[] fil = f.listFiles();
		for (File file : fil) {
			if (file.isDirectory()) {
				deleteDir(file);
				file.delete();
			} else {
				file.delete();
			}
		}
	}
}
