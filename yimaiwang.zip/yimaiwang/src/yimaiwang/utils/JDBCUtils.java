package yimaiwang.utils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.UUID;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.sun.corba.se.impl.ior.GenericTaggedComponent;

public class JDBCUtils {
private static ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();
	/**
	 * 得到数据库连接池
	 */
	public static DataSource getDataSource() {

		return comboPooledDataSource;
	}
	
	/**
	 * 得到数据连接  可以让它独立的控制事务
	 * @throws SQLException 
	 */

	public static Connection getConnection() throws SQLException{
		
		 return getDataSource().getConnection();
		
	}
 /**
  * 生成随机订单号
  * @return
  */
   public static String getOrderId(){
		
		return "order_"+Math.abs(UUID.randomUUID().toString().hashCode());
	}
}
