package yimaiwang.utils;

import javax.servlet.http.Cookie;

public class CookeiUtils {

	   public static Cookie getCookieByName(Cookie[] c,String name){
		         
		      if(c==null){
		    	  return null;
		      }else{
		    	 for (Cookie cookie : c) {
					 if(cookie.getName().equals(name)){
						 return cookie;
					 }
				} 
		    	 return null; 
		      }
		   
		   
		   
	   }
	
}
