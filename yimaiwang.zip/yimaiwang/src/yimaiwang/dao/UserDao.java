package yimaiwang.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import yimaiwang.domain.User;
import yimaiwang.utils.JDBCUtils;

public class UserDao {

	public void registUser(User user) {
		String sql = "insert into users values(null,?,?,?,?,0,null,?,?,null,null,null) ";

		Object[] params = { user.getUsername(), user.getPassword(), user.getNickname(), user.getEmail(),
				user.getState(), user.getActivecode() };
		QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			runner.update(sql, params);
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

	// 通过激活码找用户
	public User fingByActivecode(String activecode) {
		String sql = "select * from users where activecode=? ";
		Object[] parma = { activecode };
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		User user = null;
		try {
			user = queryRunner.query(sql, new BeanHandler<User>(User.class), parma);
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException("mei zhao dao uers");
		}
		return user;
	}

	// 激活用户 改变用户状态
	public void activeUser(User user) {
		String sql = "update  users set state=? where id=? ";

		Object[] params = { user.getState(), user.getId() };
		QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			runner.update(sql, params);
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

	}

	public User findByUsernameAndPassword(User user) {
		String sql = " select * from users where username= ? and password = ? ";
		Object[] obj = { user.getUsername(), user.getPassword() };
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			User user1 = queryRunner.query(sql, new BeanHandler<User>(User.class), obj);
			return user1;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

	public List<User> findAll() {
		String sql = " select * from users ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			List<User> list = queryRunner.query(sql, new BeanListHandler<User>(User.class));
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

	}

	/**
	 * 管理员添加用户
	 * 
	 * @param user
	 */
	public void insert(User user) {
		String sql = "insert into users values(null,?,?,?,?,?,null,?,?,?,?,?) ";

		Object[] params = { user.getUsername(), user.getPassword(), user.getNickname(), user.getEmail(), user.getRole(),
				user.getState(), user.getActivecode(), user.getSex(), user.getPhone(), user.getAddress() };
		QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			runner.update(sql, params);
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

	/**
	 * 通过ID查询用户
	 * 
	 * @param parseInt
	 */
	public User findById(int uid) {
		String sql = " select * from users where id=? ";
		Object[] obj = { uid };
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			User user = queryRunner.query(sql, new BeanHandler<User>(User.class), obj);
			return user;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

	}

	// 更新用户
	public void update(User user) {
		String sql = "update users set password=?,nickname=?,email=?,role=?,sex=?,phone=?,address=? where id=? ";

		Object[] params = { user.getPassword(), user.getNickname(), user.getEmail(), user.getRole(), user.getSex(),
				user.getPhone(), user.getAddress(), user.getId() };
		QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			runner.update(sql, params);
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

	// 删除用户信息
	public void delete(int uid) {
		String sql = "delete from users  where id=? ";

		Object[] params = { uid };
		QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			runner.update(sql, params);
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

	}

	// 查询所有用户数量
	public int queryAllUserCount() {
		String sql = " select count(*) from users";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			long count = (Long) queryRunner.query(sql, new ScalarHandler<Object>());
			return (int) count;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	// 查询当前页用户
	public List<User> queryCurrentPage(int page, int pageSize) {
		String sql = " select * from users limit "+(page-1)*pageSize+" , "+pageSize+" ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		  try {
			List<User> list = queryRunner.query(sql, new BeanListHandler<User>(User.class));
			return list;
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return null;
	}

}
