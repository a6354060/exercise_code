package yimaiwang.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import yimaiwang.domain.product.Product;
import yimaiwang.domain.productGate.ProductGategroyBean;
import yimaiwang.domain.productGate.ProductOne;
import yimaiwang.domain.productGate.ProductOneBean;
import yimaiwang.domain.productGate.ProductTwo;
import yimaiwang.utils.JDBCUtils;

/*
 * 商品分类的dao类
 */
public class ProductGategroyDao {

	public List<ProductOneBean> QueryClass() {
		List<ProductOneBean> list = new ArrayList<ProductOneBean>();
		ProductOneBean pob;
		List<ProductTwo> twos;

		String sql = " select * from product_one";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());

		try {
			List<ProductOne> ones = queryRunner.query(sql, new BeanListHandler<ProductOne>(ProductOne.class));

			for (ProductOne one : ones) {
				pob = new ProductOneBean();
				pob.setOne(one);

				String sql2 = " select * from product_two where p_parentid=? ";
				List<ProductTwo> list2 = queryRunner.query(sql2, new BeanListHandler<ProductTwo>(ProductTwo.class),
						one.getId());
				pob.setTwos(list2);
				list.add(pob);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

		return list;
	}

	public List<ProductOne> QueryClassOne() {
		String sql = " select * from product_one";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			List<ProductOne> list = queryRunner.query(sql, new BeanListHandler<ProductOne>(ProductOne.class));
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	// 添加one
	public void insertOne(String className) {
		String sql = " insert into product_one values(null,?)";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			queryRunner.update(sql, className);
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	// 添加two
	public void insertTwo(String className, String v2) {
		String sql = " insert into product_two values(null,?,?)";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			queryRunner.update(sql, className, v2);
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	// 修改分类2
	public void modifyTwo(int twoId, String value, int pid) {
		String sql = " update product_two set name=?,p_parentid=? where id=? ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			queryRunner.update(sql, value, pid, twoId);
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	// 修改分类1
	public void modifyOn(int oneId, String value) {
		String sql = " update product_one set name=? where id= ? ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			queryRunner.update(sql, value, oneId);
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	// 通过Id查询分类one
	public ProductOne queryOneById(String oneId) {
		String sql = " select * from product_one where id=?";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			ProductOne one = queryRunner.query(sql, new BeanHandler<ProductOne>(ProductOne.class), oneId);
			return one;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	// 通过Id查询分类two
	public ProductTwo queryTwoById(String twoId) {
		String sql = " select * from product_two where id=?";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			ProductTwo two = queryRunner.query(sql, new BeanHandler<ProductTwo>(ProductTwo.class), twoId);
			return two;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	// 通过ID删除one分类
	public void deleteOneById(String oneId) {
		String sql = " delete from product_one where id= ? ";
		String sqltwo = " delete from product_two where p_parentid= ?  ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			queryRunner.update(sql, oneId);
			queryRunner.update(sqltwo, oneId);// 跟一级分类相关的都删除
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// 通过ID删除one分类
	public void deleteTwoById(String twoId) {
		String sql = " delete from product_two where id= ? ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			queryRunner.update(sql, twoId);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/*
	 * 查询总共多少数据项
	 */
	public int queryAllCount() {
		String sql = " select count(*) from product_one";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			long count = (Long) queryRunner.query(sql, new ScalarHandler<Object>());
			return (int) count;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;

	}
/**
 * 查询第page页数据
 * @param page
 * @param pageSize
 */
	public List<ProductOneBean> queryCurrentPage(int page, int pageSize) {
		List<ProductOneBean> list = new ArrayList<ProductOneBean>();
		ProductOneBean pob;
		List<ProductTwo> twos;

		String sql = " select * from product_one limit "+(page-1)*pageSize+" , "+pageSize+" ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());

		try {
			List<ProductOne> ones = queryRunner.query(sql, new BeanListHandler<ProductOne>(ProductOne.class));

			for (ProductOne one : ones) {
				pob = new ProductOneBean();
				pob.setOne(one);

				String sql2 = " select * from product_two where p_parentid=? ";
				List<ProductTwo> list2 = queryRunner.query(sql2, new BeanListHandler<ProductTwo>(ProductTwo.class),
						one.getId());
				pob.setTwos(list2);
				list.add(pob);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

		return list;
		
	}

public List<ProductTwo> QueryClassTwo() {
	String sql = " select * from product_two";
	QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
	try {
		List<ProductTwo> list = queryRunner.query(sql, new BeanListHandler<ProductTwo>(ProductTwo.class));
		return list;
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return null;
}
}
