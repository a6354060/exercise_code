package yimaiwang.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.sun.org.apache.xpath.internal.SourceTreeManager;

import yimaiwang.domain.product.PageProduct;
import yimaiwang.domain.product.Product;
import yimaiwang.domain.product.manage.ProductBean;
import yimaiwang.domain.product.manage.ProductListBean;
import yimaiwang.domain.productGate.ProductOne;
import yimaiwang.domain.productGate.ProductTwo;
import yimaiwang.utils.FileUploadUtils;
import yimaiwang.utils.JDBCUtils;

public class ProductDao {
	// 添加商品
	public void addProduct(Product product) {
		String sql = " insert into product values(null,?,?,?,?,?,?) ";
		Object[] params = { product.getName(), product.getP_parentid(),
				product.getImg(), product.getPrice(), product.getInventory(), product.getDetail() };
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			queryRunner.update(sql, params);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

	}

	// 查找所有商品
	public List<Product> findAll() {
		String sql = " select * from product";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			List<Product> list = queryRunner.query(sql, new BeanListHandler<Product>(Product.class));
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

	// 通过ID查找商品
	public Product fingById(int id) {
		String sql = " select * from product where id=? ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			Product p = queryRunner.query(sql, new BeanHandler<Product>(Product.class), id);
			return p;
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

	}

	public String QueryImgById(String id) {
		String sql = " select img from product where id=? ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			Product p = queryRunner.query(sql, new BeanHandler<Product>(Product.class), id);
			return p.getImg();
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

	}

	// 更新商品
	public void update(Product product, int i) {
		String sql = " update product set name=?,img=?,price=?,inventory=?,detail=? where id=? ";
		Object[] params = { product.getName(), product.getImg(), product.getPrice(), product.getInventory(),
				product.getDetail(), product.getId() };
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());

		try {
			queryRunner.update(sql, params);
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

	}

	// 根据ID删除商品
	public void deleteById(int id) {
		String sql = " delete from product where id=? ";
		Object[] params = { id };
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());

		try {
			queryRunner.update(sql, params);
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

	}

	// 分页显示查询
	public List<ProductBean> pageShowDao(int page, int pageSize) {
		String sql = " select * from product limit " + (page - 1) * pageSize + ", " + pageSize;
		String sql2=" select * from product_two where id=? ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		ProductBean productBean;
		List<ProductBean> pbs;
		try {
			List<Product> list = queryRunner.query(sql, new BeanListHandler<Product>(Product.class));
			pbs=new ArrayList<ProductBean>(); 
			for (Product p : list) {
				 productBean=new ProductBean();
				 productBean.setP(p);
				 ProductTwo two = queryRunner.query(sql2, new BeanHandler<ProductTwo>(ProductTwo.class), p.getP_parentid());
				 productBean.setTwo(two);
				 pbs.add(productBean);
			}
			
			return pbs;
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return null;
	}

	public int getTotalRows() {
		String sql = " select count(*) from product ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			long l = (Long) queryRunner.query(sql, new ScalarHandler<Object>(1));
			return (int) l;
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return 0;
	}

	// 通过ID查询图片路径
	public String findProImgById(int i) {
		String sql = " select img from product where id = ? ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			String img = queryRunner.query(sql, new ScalarHandler<String>(1), i);
			return img;
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return "";
	}
// 根据Parent_id查询
	public ProductListBean queryProBeanByPid(int twoId) {
		String sql = " select * from product where p_parentid = ? ";
		String sql2 = " select * from product_one where id = ? ";
		String sql3 = " select * from product_two where id = ? ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		ProductListBean listBean=new ProductListBean();
		ProductTwo two;
		ProductOne one;
		PageProduct pagePro;
		try {
			 List<Product> list = queryRunner.query(sql, new BeanListHandler<Product>(Product.class), twoId);
			 pagePro=new PageProduct();
			 pagePro.setList(list);
			 listBean.setPagePro(pagePro);
			 two=queryRunner.query(sql3, new BeanHandler<ProductTwo>(ProductTwo.class), twoId);
			 int oneId = two.getP_parentid();
			 listBean.setTwo(two);
			 one=queryRunner.query(sql2, new BeanHandler<ProductOne>(ProductOne.class), oneId);
			 listBean.setOne(one);
			 return listBean;
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return null;
		
	}

	public ProductListBean queryProBeanByOneId(int oneId) {
		String sql = " select * from product where p_parentid = ? ";
		String sql2 = " select * from product_one where id = ? ";
		String sql3 = " select * from product_two where p_parentid = ? ";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		ProductListBean listBean=new ProductListBean();
		List<Product> pros;
		ProductOne one;
		PageProduct pagePro;
		try {
			 List<ProductTwo> twos=queryRunner.query(sql3, new BeanListHandler<ProductTwo>(ProductTwo.class), oneId);
			 pros=new ArrayList<Product>();
			 for (ProductTwo productTwo : twos) {
				 List<Product> list = queryRunner.query(sql, new BeanListHandler<Product>(Product.class), productTwo.getId());
			     pros.addAll(list);
			 }
			 pagePro=new PageProduct();
			 pagePro.setList(pros);
			 listBean.setPagePro(pagePro);
			 one=queryRunner.query(sql2, new BeanHandler<ProductOne>(ProductOne.class), oneId);
			 listBean.setOne(one);
			 return listBean;
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return null;
	}

	public List<Product> serachByName(String keyName) {
		String sql = " select * from product where name like '%"+keyName+"%'";
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			List<Product> list = queryRunner.query(sql, new BeanListHandler<Product>(Product.class));
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}		
	}
/**
 * 更改商品库存
 * @param id
 * @param value
 */
	public void updateInevn(int id, Integer value) {
		String sql = " update product set inventory=inventory-? where id=?";
		Object[] params = {value,id};
		QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
		try {
			queryRunner.update(sql, params);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}
}
