package yimaiwang.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.mchange.v2.beans.BeansUtils;

import yimaiwang.domain.User;
import yimaiwang.domain.order.DetailBean;
import yimaiwang.domain.order.Order;
import yimaiwang.domain.order.OrderBean;
import yimaiwang.domain.order.OrderDetailBean;
import yimaiwang.domain.order.OrderItem;
import yimaiwang.domain.product.Product;
import yimaiwang.domain.product.manage.ProductBean;
import yimaiwang.domain.productGate.ProductTwo;
import yimaiwang.utils.JDBCUtils;

/**
 * 订单的数据类
 * @author hp
 *
 */
public class OrderDao {
  // 添加订单
	public void addOrder(Order orders) {
		Connection conn = null;
		try {
			conn = JDBCUtils.getConnection();
			conn.setAutoCommit(false);// 开启事务
			String sql = " insert into orders values (?,?,?,null,?,?) ";
			Object[] params = { orders.getId(),orders.getUid(), orders.getUaddress(), orders.getTotalprices() ,orders.getStatu()};
			QueryRunner queryRunner = new QueryRunner();
			queryRunner.update(conn, sql, params);

			List<OrderItem> list = orders.getList();
			String sql2 = " insert into order_detail values(null,?,?,?)";

			for (OrderItem orderItem : list) {
				Object[] params2 = { orderItem.getPid(),orderItem.getPro_count(),
						orderItem.getOid()};
				queryRunner.update(conn, sql2, params2);
			}

			DbUtils.commitAndCloseQuietly(conn);

		} catch (SQLException e) {
			DbUtils.rollbackAndCloseQuietly(conn);
			e.printStackTrace();
			new RuntimeException("订单生成失败");
		}

		
	}	
	// 修改订单状态
		public void update(String orderId) {
			String sql=" update orders set statu =? where id=?";
			Object[] params={1,orderId};
			QueryRunner queryRunner=new QueryRunner(JDBCUtils.getDataSource());
			try {
				queryRunner.update(sql, params);
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("订单状态修改异常");
			}
			
		}
		public int getTotalRows() {
			String sql = " select count(*) from orders ";
			QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
			try {
				long l = (Long) queryRunner.query(sql, new ScalarHandler<Object>(1));
				return (int) l;
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			return 0;
		}
		public List<OrderBean> pageShowDao(int p, int pageSize) {
			String sql = " select * from orders limit " + (p - 1) * pageSize + ", " + pageSize;
			String sql2=" select * from users where id=? ";
			QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
			OrderBean orderBean;
			List<OrderBean> orbs;
			try {
				List<Order> list = queryRunner.query(sql, new BeanListHandler<Order>(Order.class));
				orbs=new ArrayList<OrderBean>(); 
				for (Order o : list) {
					orderBean=new OrderBean();
					 User u;
					 u = queryRunner.query(sql2, new BeanHandler<User>(User.class),o.getUid());
					 orderBean.setOrder(o);
					 orderBean.setUser(u);
					orbs.add(orderBean); 
				}
				return orbs;
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			return null;
		}
		/**
		 * 查询订单详情
		 * @param oid
		 * @return 
		 */
		public OrderDetailBean queryOrderDetail(String oid) {
			String sql=" select * from orders where id=?";
			OrderDetailBean detailBean=new OrderDetailBean();
			ArrayList<DetailBean> dbs;
			DetailBean db;
			QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
			try {
				Order order = queryRunner.query(sql, new BeanHandler<Order>(Order.class), oid);
			    detailBean.setOrder(order);
			    
			    String sql1=" select * from order_detail where oid=?";
			    
			    List<OrderItem> list = queryRunner.query(sql1, new BeanListHandler<OrderItem>(OrderItem.class), order.getId());
			    dbs=new ArrayList<DetailBean>();
			   String sql3=" select * from product where id=? ";
			    for (OrderItem orderItem : list) {
					db=new DetailBean();
					db.setOrderItem(orderItem);
					Product product = queryRunner.query(sql3, new BeanHandler<Product>(Product.class), orderItem.getPid());
					db.setProduct(product);
					dbs.add(db);
				}
			    detailBean.setList(dbs);
			    detailBean.setCount(dbs.size());
			    return detailBean;
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return null;
			
			
		}
		public List<OrderBean> personOrder(int id, int p, int pageSize) {
			String sql = " select * from orders  where uid=? limit  " + (p - 1) * pageSize + "," + pageSize;
			String sql2=" select * from users where id=? ";
			QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
			OrderBean orderBean;
			List<OrderBean> orbs;
			try {
				List<Order> list = queryRunner.query(sql, new BeanListHandler<Order>(Order.class),id);
				orbs=new ArrayList<OrderBean>(); 
				for (Order o : list) {
					orderBean=new OrderBean();
					 User u;
					 u = queryRunner.query(sql2, new BeanHandler<User>(User.class),o.getUid());
					 orderBean.setOrder(o);
					 orderBean.setUser(u);
					 orbs.add(orderBean); 
				}
				return orbs;
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			return null;
		}
		/**
		 * 根据ID删除订单
		 * @param oid
		 */
		public void deleteById(String oid) {
			 String sql=" delete from orders where id=?";
			 String sql1=" delete from order_detail where oid=?";
			 Connection conn = null;
			 try {
				 conn = JDBCUtils.getConnection();
				conn.setAutoCommit(false);// 开启事物
				QueryRunner queryRunner=new QueryRunner();
				 // 先删除订单详细表 因为有外键关联 标准是开启事物弄
				 queryRunner.update(conn,sql1, oid);
				 queryRunner.update(conn,sql, oid);
				 DbUtils.commitAndCloseQuietly(conn); 
			} catch (SQLException e) {
				 if(conn!=null){
					 DbUtils.rollbackAndCloseQuietly(conn); 
				 }
				e.printStackTrace();
			}
			 
			
		}
		/**
		 * 根据ID查询
		 * @param orderId
		 * @return 
		 */
		public Order findById(String orderId) {
			String sql=" select * from orders where id=?";
			Object[] params={orderId};
			QueryRunner queryRunner=new QueryRunner(JDBCUtils.getDataSource());
			try {
				Order order = queryRunner.query(sql, new BeanHandler<Order>(Order.class), params);
				 return order;
			} catch (SQLException e) {
				e.printStackTrace();
			} 
			return null;
		}
		// 根据用户ID查询订单个数
		public int getTotalRows(int uid) {
			String sql = " select count(*) from orders where uid=? ";
			QueryRunner queryRunner = new QueryRunner(JDBCUtils.getDataSource());
			try {
				long l = (Long) queryRunner.query(sql, new ScalarHandler<Object>(1),uid);
				return (int) l;
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			return 0;
		}

}
