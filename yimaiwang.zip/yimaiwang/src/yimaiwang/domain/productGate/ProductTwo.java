package yimaiwang.domain.productGate;

public class ProductTwo {
	private int id;
	private String name;
	private int p_parentid;

	public ProductTwo() {
		super();
	}

	public ProductTwo(int id, String name, int p_parentid) {
		super();
		this.id = id;
		this.name = name;
		this.p_parentid = p_parentid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getP_parentid() {
		return p_parentid;
	}

	public void setP_parentid(int p_parentid) {
		this.p_parentid = p_parentid;
	}
}
