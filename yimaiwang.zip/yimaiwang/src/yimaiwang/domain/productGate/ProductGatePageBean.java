package yimaiwang.domain.productGate;

import java.util.List;

/**
 * 分页信息bean
 * 
 * @author hp
 *
 */
public class ProductGatePageBean {
	private List<ProductOneBean> list; // 该页显示的数据
	private int totalPage; // 总页数
	private int totalDataNum; // 总共多少条数据
	private int currentPage; // 当前页数
	public static final int PAGE_SIZE = 5;// 每页显示多少数据

	public ProductGatePageBean() {
		super();
	}

	public ProductGatePageBean(List<ProductOneBean> list, int totalPage, int totalDataNum, int currentPage) {
		super();
		this.list = list;
		this.totalPage = totalPage;
		this.totalDataNum = totalDataNum;
		this.currentPage = currentPage;
	}

	public List<ProductOneBean> getList() {
		return list;
	}

	public void setList(List<ProductOneBean> list) {
		this.list = list;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getTotalDataNum() {
		return totalDataNum;
	}

	public void setTotalDataNum(int totalDataNum) {
		this.totalDataNum = totalDataNum;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

}
