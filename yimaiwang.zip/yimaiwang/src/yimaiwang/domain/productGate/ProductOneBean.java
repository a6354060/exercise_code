package yimaiwang.domain.productGate;

import java.util.List;

/**
 * 产品分类bean
 * 
 * @author hp
 *
 */
public class ProductOneBean {
	private ProductOne one;
	private List<ProductTwo> twos;

	public ProductOneBean() {
		super();
	}

	public ProductOneBean(ProductOne one, List<ProductTwo> twos) {
		super();
		this.one = one;
		this.twos = twos;
	}

	public ProductOne getOne() {
		return one;
	}

	public void setOne(ProductOne one) {
		this.one = one;
	}

	public List<ProductTwo> getTwos() {
		return twos;
	}

	public void setTwos(List<ProductTwo> twos) {
		this.twos = twos;
	}

}
