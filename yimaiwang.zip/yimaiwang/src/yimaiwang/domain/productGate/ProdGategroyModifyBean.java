package yimaiwang.domain.productGate;

import java.util.List;

/**
 * 分类修改bean
 * 
 * @author hp
 *
 */
public class ProdGategroyModifyBean {
	private ProductOne one;
	private List<ProductOne> ones;
	private ProductTwo two;

	public ProdGategroyModifyBean() {
		super();
	}

	public ProdGategroyModifyBean(ProductOne one, List<ProductOne> ones, ProductTwo two) {
		super();
		this.one = one;
		this.ones = ones;
		this.two = two;
	}

	public ProductOne getOne() {
		return one;
	}

	public void setOne(ProductOne one) {
		this.one = one;
	}

	public List<ProductOne> getOnes() {
		return ones;
	}

	public void setOnes(List<ProductOne> ones) {
		this.ones = ones;
	}

	public ProductTwo getTwo() {
		return two;
	}

	public void setTwo(ProductTwo two) {
		this.two = two;
	}

}
