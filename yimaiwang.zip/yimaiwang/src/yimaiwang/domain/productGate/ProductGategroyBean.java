package yimaiwang.domain.productGate;

import java.util.List;

public class ProductGategroyBean {
	private List<ProductOneBean> list;

	public ProductGategroyBean() {
		super();
	}

	public ProductGategroyBean(List<ProductOneBean> list) {
		super();
		this.list = list;
	}

	public List<ProductOneBean> getList() {
		return list;
	}

	public void setList(List<ProductOneBean> list) {
		this.list = list;
	}
}
