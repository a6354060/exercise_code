package yimaiwang.domain.productGate;

public class ProductOne {
	private int id;
	private String name;

	public ProductOne() {
		super();
	}

	public ProductOne(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
