package yimaiwang.domain.product.manage;

import yimaiwang.domain.product.Product;
import yimaiwang.domain.productGate.ProductTwo;

public class ProductBean {
    private Product p;
    private ProductTwo two;
	public Product getP() {
		return p;
	}
	public void setP(Product p) {
		this.p = p;
	}
	public ProductTwo getTwo() {
		return two;
	}
	public void setTwo(ProductTwo two) {
		this.two = two;
	}
}
