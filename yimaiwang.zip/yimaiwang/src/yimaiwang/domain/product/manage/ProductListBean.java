package yimaiwang.domain.product.manage;

import java.util.List;

import yimaiwang.domain.product.PageProduct;
import yimaiwang.domain.product.Product;
import yimaiwang.domain.productGate.ProductOne;
import yimaiwang.domain.productGate.ProductTwo;

/**
 * 展示商品列表bean
 * @author hp
 *
 */
public class ProductListBean {
	private ProductOne one;
	private ProductTwo two;
	private PageProduct pagePro;
	
	public PageProduct getPagePro() {
		return pagePro;
	}
	public void setPagePro(PageProduct pagePro) {
		this.pagePro = pagePro;
	}
	public ProductOne getOne() {
		return one;
	}
	public void setOne(ProductOne one) {
		this.one = one;
	}
	public ProductTwo getTwo() {
		return two;
	}
	public void setTwo(ProductTwo two) {
		this.two = two;
	}
	

}
