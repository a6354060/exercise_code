package yimaiwang.domain.product.manage;

import yimaiwang.domain.product.Product;

/**
 * 商品详情显示Bean
 * 
 * @author hp
 *
 */
public class ProductViewBean {
	private Product pro;
	private Double discountPrice;

	public Product getPro() {
		return pro;
	}

	public void setPro(Product pro) {
		this.pro = pro;
	}

	public Double getDiscountPrice() {
		return discountPrice;
	}

	public void setDiscountPrice(Double discountPrice) {
		this.discountPrice = discountPrice;
	}

	
}
