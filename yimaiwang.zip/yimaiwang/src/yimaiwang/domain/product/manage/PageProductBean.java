package yimaiwang.domain.product.manage;

import java.util.List;

import yimaiwang.domain.productGate.ProductTwo;

public class PageProductBean {
	public final static int PAGE_SIZE = 5;
	private int page;
	private int totalPage;
	private int pagecount;
	private List<ProductBean> list;
	private ProductTwo two;

	public ProductTwo getTwo() {
		return two;
	}

	public void setTwo(ProductTwo two) {
		this.two = two;
	}

	@Override
	public String toString() {
		return "PageProductBean [page=" + page + ", totalPage=" + totalPage + ", pagecount=" + pagecount + ", list="
				+ list + "]";
	}

	public PageProductBean() {
		super();
	}

	public PageProductBean(int page, int totalPage, int pagecount, List<ProductBean> list) {
		super();
		this.page = page;
		this.totalPage = totalPage;
		this.pagecount = pagecount;
		this.list = list;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getPagecount() {
		return pagecount;
	}

	public void setPagecount(int pagecount) {
		this.pagecount = pagecount;
	}

	public List<ProductBean> getList() {
		return list;
	}

	public void setList(List<ProductBean> list) {
		this.list = list;
	}
}
