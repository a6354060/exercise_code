package yimaiwang.domain.product;

import java.io.Serializable;

public class Product implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;
	private int p_parentid;
	private String img;
	private double price;
	private int inventory;
	private String detail;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (id != other.id)
			return false;
		return true;
	}

	public Product() {
		super();
	}

	public Product(int id, String name, int p_parentid, String img, double price, int inventory, String Detail) {
		super();
		this.id = id;
		this.name = name;
		this.p_parentid = p_parentid;
		this.img = img;
		this.price = price;
		this.inventory = inventory;
		this.detail = Detail;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", p_parentid=" + p_parentid + ", img=" + img + ", price="
				+ price + ", inventory=" + inventory + ", Detail=" + detail + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getP_parentid() {
		return p_parentid;
	}

	public void setP_parentid(int p_parentid) {
		this.p_parentid = p_parentid;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getInventory() {
		return inventory;
	}

	public void setInventory(int inventory) {
		this.inventory = inventory;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String Detail) {
		this.detail = Detail;
	}
}
