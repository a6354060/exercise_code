package yimaiwang.domain.product;

public class DiscountPro {
	private Double preferentialPrice;
	private Product pro;
	public Double getPreferentialPrice() {
		return preferentialPrice;
	}
	public void setPreferentialPrice(Double preferentialPrice) {
		this.preferentialPrice = preferentialPrice;
	}
	public Product getPro() {
		return pro;
	}
	public void setPro(Product pro) {
		this.pro = pro;
	}

}
