package yimaiwang.domain;

import java.util.List;

import yimaiwang.domain.productGate.ProductOneBean;

/**
 * 用户分页bean
 * 
 * @author hp
 *
 */
public class UserPageBean {
	private List<User> list; // 该页显示的数据
	private int totalPage; // 总页数
	private int totalDataNum; // 总共多少条数据
	private int currentPage; // 当前页数
	public static final int PAGE_SIZE = 5;// 每页显示多少数据

	public UserPageBean() {
		super();
	}

	public UserPageBean(List<User> list, int totalPage, int totalDataNum, int currentPage) {
		super();
		this.list = list;
		this.totalPage = totalPage;
		this.totalDataNum = totalDataNum;
		this.currentPage = currentPage;
	}

	public List<User> getList() {
		return list;
	}

	public void setList(List<User> list) {
		this.list = list;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getTotalDataNum() {
		return totalDataNum;
	}

	public void setTotalDataNum(int totalDataNum) {
		this.totalDataNum = totalDataNum;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public static int getPageSize() {
		return PAGE_SIZE;
	}

}
