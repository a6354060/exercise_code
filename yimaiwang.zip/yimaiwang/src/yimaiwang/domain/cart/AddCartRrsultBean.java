package yimaiwang.domain.cart;

import java.util.Map;

import yimaiwang.domain.product.Product;

/**
 * 添加购物结果bean
 * 
 * @author hp
 *
 */
public class AddCartRrsultBean {
	private Product pro;
	private int cartNum;

	public Product getPro() {
		return pro;
	}

	public void setPro(Product pro) {
		this.pro = pro;
	}

	public int getCartNum() {
		return cartNum;
	}

	public void setCartNum(int cartNum) {
		this.cartNum = cartNum;
	}

}
