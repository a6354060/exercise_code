package yimaiwang.domain.order;

import yimaiwang.domain.User;

public class OrderBean {
	  private Order order;
	  private User user;
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
}
