package yimaiwang.domain.order;


import java.util.Date;
import java.util.List;


/**
 * 订单的实体类
 * @author hp
 *
 */
public class Order {
	private String id;
	private int uid;
	private String uaddress;
	private Date createtime;
	private float totalprices;
	private int statu;
	private List<OrderItem> list;
	public List<OrderItem> getList() {
		return list;
	}
	public void setList(List<OrderItem> list) {
		this.list = list;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUaddress() {
		return uaddress;
	}
	public void setUaddress(String uaddress) {
		this.uaddress = uaddress;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public float getTotalprices() {
		return totalprices;
	}
	public void setTotalprices(float totalprices) {
		this.totalprices = totalprices;
	}
	public int getStatu() {
		return statu;
	}
	public void setStatu(int statu) {
		this.statu = statu;
	}

}
