package yimaiwang.domain.order;

import yimaiwang.domain.product.Product;

public class DetailBean {
	private Product product;
	private OrderItem orderItem;
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public OrderItem getOrderItem() {
		return orderItem;
	}
	public void setOrderItem(OrderItem orderItem) {
		this.orderItem = orderItem;
	}

}
