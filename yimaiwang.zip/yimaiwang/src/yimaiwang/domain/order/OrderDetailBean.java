package yimaiwang.domain.order;

import java.util.List;

import yimaiwang.domain.User;

/**
 * 订单详情bean
 * @author hp
 *
 */
public class OrderDetailBean {
	private Order order;
	private List<DetailBean> list;
	private int count;
	private User user ;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public List<DetailBean> getList() {
		return list;
	}
	public void setList(List<DetailBean> list) {
		this.list = list;
	}
}
