package yimaiwang.domain.order;

import java.util.List;

/**
 * 管理订单分页显示bean
 * @author hp
 *
 */
public class OrderPageBean {
	public final static int PAGE_SIZE = 5;
	private int currentPage;
	private int totalPage;
	private int pagecount;
	private List<OrderBean> list;
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	public int getPagecount() {
		return pagecount;
	}
	public void setPagecount(int pagecount) {
		this.pagecount = pagecount;
	}
	public List<OrderBean> getList() {
		return list;
	}
	public void setList(List<OrderBean> list) {
		this.list = list;
	}
	
}
