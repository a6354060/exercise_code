package yimaiwang.web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import yimaiwang.domain.User;
import yimaiwang.service.UserService;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String checkcode = (String) request.getSession().getAttribute("check_");
		request.getSession().removeAttribute("check_"); // 进行一次性验证
		System.out.println(checkcode);
		String check = request.getParameter("check");
		if (!check.equals(checkcode) || check == null) {
			request.setAttribute("message", "验证码错误！");
			request.getRequestDispatcher("register.jsp").forward(request, response);
			return;
		}

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		User user = new User();
		user.setEmail(email);
		user.setUsername(username);
		user.setPassword(password);

		UserService userService = new UserService();
		int result = userService.checkUser(user);
		switch (result) {
		case UserService.CHECK_USER_AVLIABLE:
			userService.regist(user);
			request.setAttribute("email", user.getEmail());
		    request.getRequestDispatcher("sendemail.jsp").forward(request, response);
			break;
		case UserService.CHECK_EMAIL_EXESIT:
			request.setAttribute("message", "邮箱已经存在！");
			request.getRequestDispatcher("register.jsp").forward(request, response);
			return;
		case UserService.CHECK_USER_EXESIT:
			request.setAttribute("message", "用户名已经存在！");
			request.getRequestDispatcher("register.jsp").forward(request, response);
			return;
		case UserService.CHECK_USER_NOT_AVLIABLE:
			request.setAttribute("message", "用户名异常！");
			request.getRequestDispatcher("register.jsp").forward(request, response);
			return;
		default:
			break;
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
