package yimaiwang.web.order;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alipay.api.AlipayApiException;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.constants.AlipayServiceEnvConstants;

import yimaiwang.utils.RequestUtil;

/**
 * Servlet implementation class AlipayCallbackServlet
 */
@WebServlet("/alipayCallbackNofity")
public class AlipayCallbackNotifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Map<String, String> paramsMap = RequestUtil.getRequestParams(request);
				boolean signVerified;
				try {
					signVerified = AlipaySignature.rsaCheckV1(paramsMap, AlipayServiceEnvConstants.ALIPAY_PUBLIC_KEY, AlipayServiceEnvConstants.CHARSET);
					//调用SDK验证签名
					if(signVerified){
					    // TODO 验签成功后，按照支付结果异步通知中的描述，对支付结果中的业务内容进行二次校验，校验成功后在response中返回success并继续商户自身业务处理，校验失败返回failure
					   System.out.println(paramsMap);
					}else{
					    // TODO 验签失败则记录异常日志，并在response中返回failure.
					  System.out.println(signVerified+"error");
					}
				}
				catch (AlipayApiException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
