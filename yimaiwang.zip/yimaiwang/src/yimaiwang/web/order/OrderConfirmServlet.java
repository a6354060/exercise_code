package yimaiwang.web.order;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.dao.ProductDao;
import yimaiwang.domain.product.Product;
import yimaiwang.service.OrderService;

/**
 * Servlet implementation class OrderConfirmServlet
 */
@WebServlet("/orderConfirm")
public class OrderConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String ids = request.getParameter("ids");
		String totalmoney = request.getParameter("totalmoney");
		String num1 = request.getParameter("num");
		if (ids != null && totalmoney != null) {
			HashMap<Product, Integer> map = new HashMap<Product, Integer>();
			Map<Product, Integer> cart = (Map) request.getSession().getAttribute("cart");
			ProductDao dao = new ProductDao();
			String[] i = ids.split(",");
			for (String string : i) {
				int pid = Integer.parseInt(string);
				Product product = dao.fingById(pid);
				if (cart == null || cart.size() == 0) {
					Double price = product.getPrice();
					Double valueOf = Double.valueOf(totalmoney);
					if (!valueOf.equals(price)) {
						product.setPrice(valueOf.doubleValue());
					}
					map.put(product, Integer.parseInt(num1));
				} else if(num1!=null){
					map.put(product, Integer.parseInt(num1));
				}else{
					Integer num = cart.get(product);
					map.put(product, num);	
				}
			}

			request.getSession().setAttribute("map", map);
			request.getRequestDispatcher("/confirmOrder.jsp").forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
