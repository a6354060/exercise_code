package yimaiwang.web.order;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.request.AlipayTradeWapPayRequest;
import com.alipay.constants.AlipayServiceEnvConstants;

/**
 * Servlet implementation class PayServlet
 */
@WebServlet("/aliPay")
public class AliPayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		AlipayClient alipayClient = new DefaultAlipayClient(AlipayServiceEnvConstants.ALIPAY_GATEWAY,
				AlipayServiceEnvConstants.APP_ID, AlipayServiceEnvConstants.PRIVATE_KEY, "json",
				AlipayServiceEnvConstants.CHARSET, AlipayServiceEnvConstants.ALIPAY_PUBLIC_KEY,
				AlipayServiceEnvConstants.SIGN_TYPE);
		
		  String orderId = request.getParameter("orderId");
		  String totalmoney = request.getParameter("money");
		 AlipayTradeWapPayRequest alipayRequest = new AlipayTradeWapPayRequest();//创建API对应的request
		 alipayRequest.setReturnUrl("http://localhost/yimaiwang/alipayCallback");
		 alipayRequest.setNotifyUrl("http://175.8.247.68/yimaiwang/alipayCallbackNofity");
		 alipayRequest.setBizContent("{" +
		        "    \"out_trade_no\":"+orderId+","+
		        "    \"total_amount\":"+totalmoney+"," +
		        "    \"subject\":\"易买网商品\"," +
		        "    \"seller_id\":\"2088102169486960\"," +
		        "    \"product_code\":\"QUICK_WAP_PAY\"" +
		        "  }");//填充业务参数
		    String form = null;
			try {
				form = alipayClient.pageExecute(alipayRequest).getBody();
			} catch (AlipayApiException e) {
				e.printStackTrace();
			} //调用SDK生成表单
		    response.setContentType("text/html;charset=" + AlipayServiceEnvConstants.CHARSET);
		    response.getWriter().write(form);//直接将完整的表单html输出到页面
		    response.getWriter().flush();

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
