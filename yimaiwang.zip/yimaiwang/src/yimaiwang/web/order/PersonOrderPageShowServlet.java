package yimaiwang.web.order;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.domain.User;
import yimaiwang.domain.order.OrderPageBean;
import yimaiwang.service.OrderService;

/**
 */
@WebServlet(name = "PersonOrderServlet", urlPatterns = { "/personOrder" })
public class PersonOrderPageShowServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String page=request.getParameter("page");
		 OrderService orderService=new OrderService();
		 User user=(User) request.getSession().getAttribute("user");
		 OrderPageBean pageShow = orderService.personOrder(user.getId(),page);
		 request.setAttribute("bean", pageShow);
		 request.getRequestDispatcher("/UserOrderInfo.jsp").forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
