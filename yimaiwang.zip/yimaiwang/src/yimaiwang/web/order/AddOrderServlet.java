package yimaiwang.web.order;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sun.awt.RepaintArea;
import yimaiwang.domain.User;
import yimaiwang.domain.order.Order;
import yimaiwang.domain.product.Product;
import yimaiwang.service.OrderService;
import yimaiwang.utils.PaymentUtil;

/**
 * Servlet implementation class AddOrderServlet
 */
@WebServlet("/addOrder")
public class AddOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		  
		  String money = request.getParameter("totalmoney");
		  request.setAttribute("money", money);
		  request.setAttribute("oid", PaymentUtil.getOrderId());
		  request.getRequestDispatcher("/toPay.jsp").forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
