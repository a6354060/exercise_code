package yimaiwang.web.order;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.domain.User;
import yimaiwang.domain.order.OrderDetailBean;
import yimaiwang.service.OrderService;

/**
 * Servlet implementation class PersonOrderDetailServlet
 */
@WebServlet("/personOrderDetail")
public class PersonOrderDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		   String oid = request.getParameter("id");
		   OrderService orderService=new OrderService();
		   User user=(User) request.getSession().getAttribute("user");
		   OrderDetailBean orderDetail = orderService.orderDetail(oid,user.getId()+"");
		   request.setAttribute("detailBean", orderDetail);
		   request.getRequestDispatcher("/personOrderDetail.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
