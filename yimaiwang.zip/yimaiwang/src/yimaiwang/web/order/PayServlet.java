package yimaiwang.web.order;

import java.io.IOException;
import java.util.HashMap;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.dao.OrderDao;
import yimaiwang.domain.User;
import yimaiwang.domain.order.Order;
import yimaiwang.domain.product.Product;
import yimaiwang.service.OrderService;

/**
 * Servlet implementation class PayServlet
 */
@WebServlet("/pay")
public class PayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String orderId = request.getParameter("orderId");
		String payWay = request.getParameter("payWay");
		String money = request.getParameter("money");
		
		
		if("1".equals(payWay)){
			 // 支付宝支付
			 boolean exist = orderExist(orderId); // 判断订单是否存在
			 if(exist){
				 request.setAttribute("order_id", orderId);
				 request.setAttribute("totalmoney", money);
				 request.getRequestDispatcher("/aliPay").forward(request, response); 
			 }else{
			 OrderService orderService=new OrderService();
			 HashMap<Product, Integer> map=(HashMap<Product, Integer>) request.getSession().getAttribute("map");
			 User u= (User) request.getSession().getAttribute("user");
			// 添加订单 
			 orderService.addOrder(money,map,u,orderId); 
			 // 修改购物车
			 HashMap<Product, Integer> cart=(HashMap<Product, Integer>) request.getSession().getAttribute("cart");
			 if(cart!=null){
				 Set<Product> key = map.keySet();
				  for (Product product : key) {
					cart.remove(product); 
				  }
				 }
			 request.setAttribute("order_id", orderId);
			 request.setAttribute("totalmoney", money);
			 request.getRequestDispatcher("/aliPay").forward(request, response);
			 }
			 
		 } else if("2".equals(payWay)){
			 // 易宝支付
			 boolean exist = orderExist(orderId); // 判断订单是否存在
			 if(exist){
				 // 订单存在
				 request.setAttribute("order_id", orderId);
				 request.setAttribute("totalmoney", money);
				 request.getRequestDispatcher("/yibaopay.jsp").forward(request, response); 
			 }else{
       // 订单不存在			 
			 OrderService orderService=new OrderService();
			 HashMap<Product, Integer> map=(HashMap<Product, Integer>) request.getSession().getAttribute("map");
			 User u= (User) request.getSession().getAttribute("user");
			 Order order = orderService.addOrder(money,map,u,orderId);
			 // 修改购物车
			 HashMap<Product, Integer> cart=(HashMap<Product, Integer>) request.getSession().getAttribute("cart");
			 if(cart!=null){
			 Set<Product> key = map.keySet();
			  for (Product product : key) {
				cart.remove(product); 
			  }
			 }
			 request.setAttribute("order_id", orderId);
			 request.setAttribute("totalmoney", money);
			 request.getRequestDispatcher("/yibaopay.jsp").forward(request, response);
			 } 
		 } 
		 
		
		

	}
/**
 * 判断订单是否存在
 * @param orderId
 */
	private boolean orderExist(String orderId) {
		  OrderDao dao=new OrderDao();
		  Order order = dao.findById(orderId);
		  if(order!=null){
			  return true;
		  }else{
			  return false;
		  }
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
