package yimaiwang.web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import com.sun.xml.internal.bind.v2.runtime.output.StAXExStreamWriterOutput;

import yimaiwang.dao.UserDao;
import yimaiwang.domain.User;
import yimaiwang.service.UserService;

@WebServlet("/updatePersonalInfo")
public class UpdatePersonalInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Map<String, String[]> map = request.getParameterMap();
		 User user=new User();
		 try {
			BeanUtils.populate(user, map);
			user.setRole(0);
			boolean isupdatePass=false;
			User u=(User) request.getSession().getAttribute("user");
			if(user.getPassword()==""){
			    user.setPassword(u.getPassword());
			    isupdatePass=false;
			}else{
				isupdatePass=true;
			}
			UserService service=new UserService();
			int result = service.checkUser(user,u);
			
			switch (result) {
			case UserService.CHECK_USER_AVLIABLE:
				service.completeUser(user,isupdatePass);
				// sessio中的user值重新新更改下
				UserDao dao=new UserDao();
				User user2 = dao.findById(user.getId());
				request.getSession().setAttribute("user", user2);
			    request.getRequestDispatcher("/userInfoUpdate-result.jsp").forward(request, response);
				break;
			case UserService.CHECK_EMAIL_EXESIT:
				request.setAttribute("message", "邮箱已经存在！");
				request.getRequestDispatcher("/CompleteUserInfo.jsp").forward(request, response);
				return;
			default:
				service.completeUser(user,isupdatePass);
			    request.getRequestDispatcher("/userInfoUpdate-result.jsp").forward(request, response);
				return;
			}
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
