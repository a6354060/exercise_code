package yimaiwang.web.cart;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.dao.ProductDao;
import yimaiwang.domain.cart.AddCartRrsultBean;
import yimaiwang.domain.product.Product;
import yimaiwang.service.ProductService;
import yimaiwang.utils.NumUtils;



@WebServlet("/addCart")
public class AddCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
          String id=request.getParameter("pid");
          String num1=request.getParameter("num");
	    ProductService productService= new ProductService();
	     if(NumUtils.isNum(id)){
	    	 int pid=Integer.parseInt(id);
	    	 Product p=productService.findProductById(pid);
	    @SuppressWarnings("unchecked")
		Map<Product,Integer> cart=(Map<Product, Integer>) request.getSession().getAttribute("cart");
	       if(cart==null){
	    	 cart=new HashMap<Product,Integer>();
	    	 cart.put(p, Integer.parseInt(num1));
	       }else{
	    	    if(cart.containsKey(p)){
	    	        int num=cart.get(p);
	    	        cart.put(p,num+1);
	    	    }else{
	    	      cart.put(p, Integer.parseInt(num1));	
	    	    } 
	       }
	       request.getSession().setAttribute("cart", cart);
	       int size = cart.size();
	       AddCartRrsultBean bean=new AddCartRrsultBean();
	       bean.setCartNum(size);
	       bean.setPro(p);
	       request.setAttribute("bean", bean);
	       request.getRequestDispatcher("/addCartResultView.jsp").forward(request, response);
	     }else{
	    	 response.sendRedirect("/yimaiwang/index.jsp");
	     }
	     
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
