package yimaiwang.web.cart;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.dao.ProductDao;
import yimaiwang.domain.product.Product;

/**
 * Servlet implementation class ReduceNumServlet
 */
@WebServlet("/addNum")
public class AddNumServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int num = Integer.parseInt(request.getParameter("num"));
		String id = request.getParameter("id");
		ProductDao dao=new ProductDao();
		Product product = dao.fingById(Integer.parseInt(id));
		Map<Product, Integer> cart = (Map<Product, Integer>) request.getSession().getAttribute("cart");
		if(product.getInventory()<=num){
			cart.put(product, product.getInventory());
		}else{
			cart.put(product, num+1);
		}	
		
			response.sendRedirect("shopping.jsp");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
