package yimaiwang.web.product;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.domain.product.Product;
import yimaiwang.domain.product.manage.ProductViewBean;
import yimaiwang.service.ProductService;

@WebServlet("/productViewShow")
public class ProductViewShowServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pid = request.getParameter("pid");
		String discountPrice = request.getParameter("discountPrice");
		ProductService productService = new ProductService();
		ProductViewBean productViewBean = productService.showProductView(pid, discountPrice);
		// 保存最近浏览商品
		List<Product> rec = (List<Product>) request.getSession().getAttribute("recentPro");
		List<Product> recentPro = productService.saveRecentPro(productViewBean.getPro(), rec);
		request.setAttribute("viewProBean", productViewBean);
		request.getSession().setAttribute("recentPro", recentPro);
		
		request.getRequestDispatcher("/product-view.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
