package yimaiwang.web.product;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.domain.product.Product;
import yimaiwang.domain.product.manage.ProductListBean;
import yimaiwang.service.ProductService;

/**
 * Servlet implementation class ProductListServlet
 */
@WebServlet("/productList")
public class ProductListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		  String twoId = request.getParameter("twoId");
		  String oneId = request.getParameter("oneId");
		  String currentP = request.getParameter("page");
		  
		  ProductService service=new ProductService();
		  ProductListBean proShowBean = service.showProductByParentId(twoId,oneId,currentP);
		  request.setAttribute("proShowBean", proShowBean);
		  request.getRequestDispatcher("/product-list.jsp").forward(request, response);
		  
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
