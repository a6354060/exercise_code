package yimaiwang.web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import yimaiwang.domain.User;
import yimaiwang.service.UserService;
import yimaiwang.utils.CookeiUtils;
import yimaiwang.utils.MD5Utils;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		// 验证码 验证
//		String checkcode = (String) request.getSession().getAttribute("check_");
//		request.getSession().removeAttribute("check_");
//		String veryCode = request.getParameter("veryCode");
//		if (!checkcode.equals(veryCode) || veryCode == null) {
//			request.setAttribute("message", "验证码错误！");
//			request.getRequestDispatcher("/login.jsp").forward(request, response);
//			return;
//		}
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		// 是否记住用户名密码
		String parameter = request.getParameter("rememberUser");
         if(parameter!=null&&"1".equals(parameter)){
        	 // 保存用户名密码到cookie中
        	 Cookie usernameCookie=new Cookie("username", URLEncoder.encode(username, "UTF-8"));
        	 usernameCookie.setPath("/");
        	 usernameCookie.setMaxAge(30*24*3600);// 保存一个月
        	 response.addCookie(usernameCookie);
        	 
        	 Cookie passCookie=new Cookie("password", password);
        	 passCookie.setPath("/");
        	 passCookie.setMaxAge(30*24*3600);// 保存一个月
        	 response.addCookie(passCookie);
        	  System.out.println(passCookie.getValue()+"value"); 
         }else{
        	 Cookie passCookie=new Cookie("password", null);
        	 passCookie.setPath("/");
        	 passCookie.setMaxAge(30*24*3600);// 保存一个月
        	 response.addCookie(passCookie);
        	 
        	 Cookie usernameCookie=new Cookie("username", null);
        	 usernameCookie.setPath("/");
        	 usernameCookie.setMaxAge(30*24*3600);// 保存一个月
        	 response.addCookie(usernameCookie);
         }
         
		User user = new User();
		user.setUsername(username);
	    user.setPassword(password);
		// 调用业务层处理
		UserService service = new UserService();
		User u = service.login(user);
		if (u != null) {
			if (u.getState() != 1) {
				request.setAttribute("message", "用户未激活 请去您注册的邮箱激活用户");
				request.getRequestDispatcher("/login.jsp").forward(request, response);
				return;
			} else {
				request.getSession().setAttribute("user", u);
				if(u.getRole()==1){
					response.sendRedirect("manage/index.jsp");
				}else{
					response.sendRedirect("index.jsp");
				}
				return;
			}
		} else {
			request.setAttribute("message", "用户名或者密码不正确");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
