package yimaiwang.web.manage.order;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.domain.order.OrderDetailBean;
import yimaiwang.service.OrderService;

/**
 * Servlet implementation class OrderDetailServlet
 */
@WebServlet("/manage/orderDetail")
public class OrderDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		   String oid = request.getParameter("id");
		   String uid = request.getParameter("uid");
		   OrderService orderService=new OrderService();
		   OrderDetailBean orderDetail = orderService.orderDetail(oid,uid);
		   request.setAttribute("detailBean", orderDetail);
		   request.getRequestDispatcher("/manage/order-view.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
