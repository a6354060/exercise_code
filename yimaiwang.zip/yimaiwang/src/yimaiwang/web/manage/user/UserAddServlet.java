package yimaiwang.web.manage.user;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import yimaiwang.domain.User;
import yimaiwang.service.UserService;

/**
 * Servlet implementation class UserAddServlet
 */
@WebServlet("/manage/userAdd")
public class UserAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		 Map<String, String[]> map = request.getParameterMap();
		 User user=new User();
		 try {
			BeanUtils.populate(user, map);
			UserService service=new UserService();
			int result = service.checkUser(user);
			
			switch (result) {
			case UserService.CHECK_USER_AVLIABLE:
				service.addUser(user);
				int totalPage = service.getTotalPage();
			    response.sendRedirect("/yimaiwang/manage/userPageShow?page="+totalPage);
				break;
			case UserService.CHECK_EMAIL_EXESIT:
				request.setAttribute("message", "邮箱已经存在！");
				request.getRequestDispatcher("/manage/user-add.jsp").forward(request, response);
				return;
			case UserService.CHECK_USER_EXESIT:
				request.setAttribute("message", "用户名已经存在！");
				request.getRequestDispatcher("/manage/user-add.jsp").forward(request, response);
				return;
			case UserService.CHECK_USER_NOT_AVLIABLE:
				request.setAttribute("message", "用户名异常！");
				request.getRequestDispatcher("/manage/user-add.jsp").forward(request, response);
				return;
			default:
				break;
			}
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
