package yimaiwang.web.manage.productGategory;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.service.ProductGategoryService;
import yimaiwang.utils.NumUtils;

/**
 * Servlet implementation class GateValueModifyServlet
 */
@WebServlet("/manage/gateValueModify")
public class GateValueModifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String oneId = request.getParameter("oneId");
		String twoId = request.getParameter("twoId");
		String classOneName = request.getParameter("classOneName");
		String classTwoName = request.getParameter("classTwoName");
		String modifyOneId = request.getParameter("modifyoneId");
		String currentPage = request.getParameter("currentPage");
		int page = 1;
		if (NumUtils.isNum(currentPage)) {
			page = Integer.parseInt(currentPage);
		}
		ProductGategoryService service = new ProductGategoryService();
		service.modify(oneId, twoId, classOneName, classTwoName, modifyOneId);
		response.sendRedirect("/yimaiwang/manage/showProductClass?page="+page);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
