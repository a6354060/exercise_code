package yimaiwang.web.manage.productGategory;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.service.ProductGategoryService;
import yimaiwang.utils.NumUtils;

/**
 * Servlet implementation class GateDeleteServlet
 */
@WebServlet("/manage/gateDelete")
public class GateDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		  String oneId = request.getParameter("oneId");
		  String twoId = request.getParameter("twoId");
		  String currentPage = request.getParameter("currentPage");
		  int page=1;
		  if(NumUtils.isNum(currentPage)){
			  page=Integer.parseInt(currentPage);
		  }
		  ProductGategoryService service=new ProductGategoryService();
		  service.deleteGate(oneId,twoId);
		  response.sendRedirect("/yimaiwang/manage/showProductClass?page="+page);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	


}
