package yimaiwang.web.manage.productGategory;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.service.ProductGategoryService;

/**
 * Servlet implementation class GategoryAddServlet
 */
@WebServlet("/gategoryAdd")
public class GategoryAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String value = request.getParameter("gategory1");
		String className = request.getParameter("className");
		ProductGategoryService gategoryService = new ProductGategoryService();
		
		if ("1".equals(value)) {
			// 添加到分类1
			gategoryService.insertOne(className);
			int totalPage = gategoryService.getTotalPage();
			response.sendRedirect("manage/showProductClass?page="+totalPage);
		}

		if ("2".equals(value)) {
			// 添加到分类2
			String v2 = request.getParameter("gategory2");
			gategoryService.insertTwo(className, v2);
			int totalPage = gategoryService.getTotalPage();
			response.sendRedirect("manage/showProductClass?page="+totalPage);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
