package yimaiwang.web.manage.productGategory;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.domain.productGate.ProdGategroyModifyBean;
import yimaiwang.service.ProductGategoryService;

/**
 * Servlet implementation class GategroyModifyServlet
 */
@WebServlet("/manage/gategroyModify")
public class GategroyModifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String oneId = request.getParameter("oneId");
		String twoId = request.getParameter("twoId");
			 ProductGategoryService service=new ProductGategoryService();
				ProdGategroyModifyBean gate = service.queryGate(twoId,oneId);
				request.setAttribute("gate", gate);
				request.getRequestDispatcher("/manage/productClass-modify.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
