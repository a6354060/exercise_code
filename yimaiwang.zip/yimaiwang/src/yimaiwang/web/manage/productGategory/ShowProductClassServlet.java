package yimaiwang.web.manage.productGategory;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.domain.productGate.ProductGatePageBean;
import yimaiwang.service.ProductGategoryService;

/**
 * Servlet implementation class ShowProductClassServlet
 */
@WebServlet("/manage/showProductClass")
public class ShowProductClassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 String page = request.getParameter("page");
		 ProductGategoryService service=new ProductGategoryService();
		 ProductGatePageBean pageBean = service.gatePageShwo(page);
		 request.setAttribute("bean", pageBean);
		 request.getRequestDispatcher("/manage/productClass.jsp").forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
