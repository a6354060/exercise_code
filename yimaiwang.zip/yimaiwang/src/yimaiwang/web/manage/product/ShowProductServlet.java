package yimaiwang.web.manage.product;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.domain.product.Product;
import yimaiwang.domain.product.manage.PageProductBean;
import yimaiwang.service.ProductService;


@WebServlet("/manage/showProduct")
public class ShowProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		  ProductService productService= new ProductService();
		  String page=request.getParameter("page");
	      PageProductBean bean= productService.pageShow(page);
	      request.setAttribute("bean", bean);
	      request.getRequestDispatcher("/manage/product.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	

}
