package yimaiwang.web.manage.product;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.domain.product.Product;
import yimaiwang.service.ProductService;

/**
 * Servlet implementation class ProductMServlet
 */
@WebServlet("/manage/productM")
public class ProductMServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		  String i=request.getParameter("id");
		  int id=Integer.parseInt(i);
		  ProductService productService=new ProductService();
		  Product p= productService.findProductById(id);
		 
		 request.setAttribute("product", p);
		 request.getRequestDispatcher("/manage/product-modify.jsp").forward(request, response);
		 
		  
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
