package yimaiwang.web.manage.product;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.util.Streams;

import yimaiwang.dao.ProductDao;
import yimaiwang.domain.product.Product;
import yimaiwang.service.ProductService;
import yimaiwang.utils.FileUploadUtils;

@WebServlet("/manage/modifyProduct")
public class ModifyProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		if (ServletFileUpload.isMultipartContent(request)) {
			DiskFileItemFactory dif = new DiskFileItemFactory();

			ServletFileUpload fileuplode = new ServletFileUpload(dif);

			fileuplode.setFileSizeMax(5 * 1024 * 1024); // 最大上传5兆的文件
			fileuplode.setHeaderEncoding("utf-8"); // 那文件名不会乱码
			Product product = new Product();
			ProductService productService = new ProductService();
			// 解析该情求字段
			try {
				List<FileItem> list = fileuplode.parseRequest(request);
				for (FileItem fileItem : list) {
					if (fileItem.isFormField()) {
						String name = fileItem.getFieldName();
						String value = fileItem.getString("utf-8");
						if (name != null) {
							switch (name) {
							case "id":
								product.setId(Integer.parseInt(value));
								break;
							case "name":
								product.setName(value);
								break;
							case "price":
								product.setPrice(Double.valueOf(value));
								break;
							case "inventory":
								product.setInventory(Integer.valueOf(value));
								break;
							case "detail":
								product.setDetail(value);
								break;
							default:
								break;
							}
						}
					} else {
						// 是文件上传
						String fileName = fileItem.getName();

						if (fileName == null || fileName.trim().equals("")) {
							/*response.getWriter().print(
									"<script>alert('不能上传空文件！');location='/yimaiwang/manage/product-add.jsp'</script>");
							return;*/
							ProductDao dao=new ProductDao();
							product.setImg( dao.findProImgById(product.getId()));
						} else {
							String subfileName = FileUploadUtils.subFileName(fileName);// 拿到文件名

							// 判断是否是图片
							String contentType = fileItem.getContentType();// 得到上传文件类型

							boolean isValid = FileUploadUtils.isImage(contentType);

							if (!isValid) {
								response.getWriter().print(
										"<script>alert('上传文件必须是图片呢！');location='/yimaiwang/manage/product-add.jsp'</script>");
								return;
							}

							String uuidname = FileUploadUtils.getUUIDName(fileName);// 生成文件名

							String randir = FileUploadUtils.multiFolder(uuidname);// 得到多级目录

							File dir = new File(getServletContext().getRealPath("/images/product" + randir));
							dir.mkdirs(); // 文件夹不存在 就创建
							InputStream in = new BufferedInputStream(fileItem.getInputStream());

							BufferedOutputStream out = new BufferedOutputStream(
									new FileOutputStream(new File(dir, uuidname)));// 上传文件的位置

							byte[] b = new byte[1024];
							int i = 0;
							while ((i = in.read(b)) != -1) {
								out.write(b, 0, i);
							}
							in.close();
							out.close();
							// 在本地也保持一份保证图片有
							FileInputStream fis = new FileInputStream(new File(dir, uuidname));
							File f = new File("D:/jinkeying/yimaiwang/WebContent/images/product" + randir + "/");
							if (!f.exists())
								f.mkdirs();
							FileOutputStream fos = new FileOutputStream(new File(f, uuidname));
							Streams.copy(fis, fos, true);
							product.setImg("/yimaiwang/images/product" + randir + "/" + uuidname);
							fileItem.delete(); // 删除临时文件

						}
					}

				}
				productService.deletePic(product.getId(), getServletContext());// 删除修改前的图片
				productService.modify(product, product.getId());
				response.sendRedirect("/yimaiwang/manage/showProduct?page=1");

			} catch (FileUploadException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}

		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
