package yimaiwang.filter;

import java.io.IOException;
import java.net.URLDecoder;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.dao.UserDao;
import yimaiwang.domain.User;
import yimaiwang.service.UserService;
import yimaiwang.utils.CookeiUtils;

/**
 * Servlet Filter implementation class AutoLoginFilter
 */
@WebFilter(
		dispatcherTypes = {DispatcherType.REQUEST },
		urlPatterns = {"/"})
public class AutoLoginFilter implements Filter {

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		chain.doFilter(request, response);
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		//String resourcePath = httpRequest.getRequestURI().substring(request.getServletContext().getContextPath().length());
		if (httpRequest.getSession().getAttribute("user") != null) {
			chain.doFilter(request, response);
		} else {
			Cookie[] c = httpRequest.getCookies();
			Cookie usernameCookie = CookeiUtils.getCookieByName(c, "username");
			Cookie passwordCookie = CookeiUtils.getCookieByName(c, "autopassword");
			if (usernameCookie != null && passwordCookie != null) {
				UserDao dao=new UserDao();
				User user = new User();
				user.setUsername(URLDecoder.decode(usernameCookie.getValue(), "UTF-8"));
				user.setPassword(passwordCookie.getValue());
				dao.findByUsernameAndPassword(user);
				httpRequest.getSession().setAttribute("user", user);
				chain.doFilter(httpRequest, httpResponse);
			} else {
				chain.doFilter(httpRequest, httpResponse);
			}
			
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {
	}

}
