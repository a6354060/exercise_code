package yimaiwang.filter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yimaiwang.domain.User;

/**
 * Servlet Filter implementation class PrivilegeFileter
 */
@WebFilter("/*")
public class PrivilegeFileter implements Filter {
	List<String> user_Privilege = new ArrayList<String>();
	// List<String> admin_Privilege = new ArrayList<String>();

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request2 = (HttpServletRequest) request;
		HttpServletResponse response2 = (HttpServletResponse) response;
		String resourcePath = request2.getRequestURI().substring(request.getServletContext().getContextPath().length());
		if (user_Privilege.contains(resourcePath) || resourcePath.startsWith("/manage/")) {
			User user = (User) request2.getSession().getAttribute("user");
			if (user == null) {
				// 未登录
				// request2.setAttribute("message", "您访问的资源需要登录！");
				response2.sendRedirect("/yimaiwang/login.jsp");
				return;
			} else {
				// 已经登录
				int role = user.getRole();
				if (role == 0) {
					// 商城用户
					if (user_Privilege.contains(resourcePath)) {
						// 权限满足
						chain.doFilter(request2, response);
					} else {
						// 权限不足
						response2.setContentType("text/html;charset=utf-8");
						response2.getWriter().print("<script>alert('权限不足！');location='/yimaiwang/index.jsp'</script>");
					}
				} else if (role == 1) {
					// 管理员用户 可以访问任何界面
					chain.doFilter(request2, response);
				}

			}
		} else {
			// 游客
			chain.doFilter(request2, response);
		}

	}

	public void init(FilterConfig fConfig) throws ServletException {
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(PrivilegeFileter.class.getResource("/user.txt").getFile())));
			String s = null;
			while ((s = br.readLine()) != null) {
				user_Privilege.add(s);
			}
			br.close();

			// BufferedReader br1 = new BufferedReader(new InputStreamReader(
			// new
			// FileInputStream(PrivilegeFileter.class.getResource("/admin.txt").getFile())));
			// String s1 = null;
			// while ((s1 = br1.readLine()) != null) {
			// admin_Privilege.add(s1);
			// }
			// br1.close();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

}
