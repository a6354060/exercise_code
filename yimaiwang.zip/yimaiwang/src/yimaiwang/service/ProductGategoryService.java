package yimaiwang.service;

import java.util.List;

import yimaiwang.dao.ProductGategroyDao;
import yimaiwang.domain.productGate.ProdGategroyModifyBean;
import yimaiwang.domain.productGate.ProductGatePageBean;
import yimaiwang.domain.productGate.ProductOne;
import yimaiwang.domain.productGate.ProductOneBean;
import yimaiwang.domain.productGate.ProductTwo;

/**
 * 商品分类业务类
 * 
 * @author hp
 *
 */
public class ProductGategoryService {

	public List<ProductOneBean> queryProductClass() {
		ProductGategroyDao dao = new ProductGategroyDao();
		List<ProductOneBean> queryClass = dao.QueryClass();

		return queryClass;
	}

	// 查询one的信息
	public List<ProductOne> queryOne() {
		ProductGategroyDao dao = new ProductGategroyDao();
		List<ProductOne> queryClassOne = dao.QueryClassOne();

		return queryClassOne;
	}
	// 查询two的信息
	public List<ProductTwo> queryTwo() {
		ProductGategroyDao dao = new ProductGategroyDao();
		List<ProductTwo> queryClassTwo = dao.QueryClassTwo();
		
		return queryClassTwo;
	}

	// 添加到分类1
	public void insertOne(String className) {
		ProductGategroyDao dao = new ProductGategroyDao();
		dao.insertOne(className);
	}

	// 添加到分类2
	public void insertTwo(String className, String v2) {
		ProductGategroyDao dao = new ProductGategroyDao();
		dao.insertTwo(className, v2);

	}

	// 修改分类2
	public void modifyTwo(String twoId, String value, String pid) {
		ProductGategroyDao dao = new ProductGategroyDao();
		dao.modifyTwo(Integer.parseInt(twoId), value, Integer.parseInt(pid));
	}

	// 修改分类1
	public void modifyOne(String oneId, String value) {
		ProductGategroyDao dao = new ProductGategroyDao();
		dao.modifyOn(Integer.parseInt(oneId), value);
	}

	// 根据Id查询分类
	public ProdGategroyModifyBean queryGate(String twoId, String oneId) {
		ProductGategroyDao dao = new ProductGategroyDao();
		ProdGategroyModifyBean pgmb = null;
		if (oneId!=null) {
			pgmb = new ProdGategroyModifyBean();
			ProductOne one = dao.queryOneById(oneId);
			List<ProductOne> ones = dao.QueryClassOne();
			pgmb.setOnes(ones);
			pgmb.setOne(one);
			if (twoId!=null) {
				ProductTwo two = dao.queryTwoById(twoId);
				pgmb.setTwo(two);
				List<ProductOne> on = dao.QueryClassOne();
				pgmb.setOnes(on);
			}
		}

		return pgmb;
	}

	/**
	 * 修改分类
	 * 
	 * @param oneId
	 * @param twoId
	 * @param classOneName
	 * @param classTwoName
	 * @param modifyOneId
	 */
	public void modify(String oneId, String twoId, String classOneName, String classTwoName, String modifyOneId) {

		if (oneId != null) {
			// 修改one
			modifyOne(oneId, classOneName);
		} else if (twoId != null) {
			modifyTwo(twoId, classTwoName, modifyOneId);
		}
	}

	/**
	 * 删除分类
	 * 
	 * @param oneId
	 * @param twoId
	 */
	public void deleteGate(String oneId, String twoId) {

		if (oneId != null && isNum(oneId)) {
			ProductGategroyDao dao = new ProductGategroyDao();
			dao.deleteOneById(oneId);
		}
		if (twoId != null && isNum(twoId)) {
			ProductGategroyDao dao = new ProductGategroyDao();
			dao.deleteTwoById(twoId);
		}

	}

	/*
	 * 判断是否是数字
	 */
	private boolean isNum(String num) {
		try {
			Integer.parseInt(num);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	// 分页显示分类信息
	public ProductGatePageBean gatePageShwo(String p) {
		int page = 0;
		ProductGatePageBean pageBean = new ProductGatePageBean();

		ProductGategroyDao dao = new ProductGategroyDao();
		// 得到总共有多少数据项
		int allCount = dao.queryAllCount();
		pageBean.setTotalDataNum(allCount);

		// 总共分多少页
		int totalPage = (allCount + ProductGatePageBean.PAGE_SIZE - 1) / ProductGatePageBean.PAGE_SIZE;
		pageBean.setTotalPage(totalPage);

		if (isNum(p)) {
			page = Integer.parseInt(p);
		}

		if (page > totalPage) {
			page = totalPage;
		}
		if (page <= 0) {
			page = 1;
		}
		// 设置当前多少页
		pageBean.setCurrentPage(page);
		// 得到显示数据
		List<ProductOneBean> list = dao.queryCurrentPage(page, ProductGatePageBean.PAGE_SIZE);
		pageBean.setList(list);

		return pageBean;
	}

	/**
	 * 
	 */
	public int getTotalPage() {
		ProductGategroyDao dao = new ProductGategroyDao();
		// 得到总共有多少数据项
		int allCount = dao.queryAllCount();
		int totalPage = (allCount + ProductGatePageBean.PAGE_SIZE - 1) / ProductGatePageBean.PAGE_SIZE;
		return totalPage;

	}
}
