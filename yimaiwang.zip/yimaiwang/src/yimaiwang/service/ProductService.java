package yimaiwang.service;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletContext;

import yimaiwang.dao.ProductDao;
import yimaiwang.domain.product.DiscountPro;
import yimaiwang.domain.product.PageProduct;
import yimaiwang.domain.product.Product;
import yimaiwang.domain.product.manage.PageProductBean;
import yimaiwang.domain.product.manage.ProductBean;
import yimaiwang.domain.product.manage.ProductListBean;
import yimaiwang.domain.product.manage.ProductViewBean;
import yimaiwang.utils.FileUploadUtils;
import yimaiwang.utils.NumUtils;

/**
 * 商品的业务类
 * 
 * @author hp
 *
 */
public class ProductService {

	private static final int PAGE_SIZE = 5;

	public void insert(Product product) {
		ProductDao productDao = new ProductDao();
		productDao.addProduct(product);

	}

	// 查找所有商品
	public List<Product> findAllProduct() {
		ProductDao productDao = new ProductDao();
		List<Product> list = productDao.findAll();
		return list;
	}

	List<Integer> temp = new ArrayList<Integer>(); // 保存折扣 和 显示的不重复
	// 随机取8个商品没有8个全部取出

	public List<Product> showProduct() {

		List<Product> list = findAllProduct();
		if (list.size() <= 12) {
			return list;
		} else {
			List<Product> list2 = new ArrayList<Product>();
			Random ran = new Random();
			for (int i = 0; i < 12; i++) {
				int random = ran.nextInt(list.size());
				if (!isContain(temp, random)) {
					temp.add(random);
					list2.add(list.get(random));
				} else {
					i--; // 重新取值
				}
			}
			return list2;
		}
	}

	// 随机取5个折扣商品
	public List<DiscountPro> showDiscountProduct() {

		List<Product> list = findAllProduct();
		List<DiscountPro> dList = new ArrayList<DiscountPro>();
		DiscountPro dp;
		Random random = new Random();
		MathContext mc = new MathContext(3);
		if (list.size() <= 13) {
			for (int i = 0; i < list.size() - 8; i++) {
				dp = new DiscountPro();
				double price = list.get(i).getPrice();
				double discount = random.nextDouble() * (price * 0.2);
				BigDecimal bd = new BigDecimal(price, mc);
				BigDecimal b = new BigDecimal(discount, mc);
				dp.setPreferentialPrice(Double.valueOf(bd.subtract(b).toString()));
				dp.setPro(list.get(i));
				dList.add(dp);
			}
			return dList;
		} else {
			for (int i = 0; i < 6; i++) {
				int ra = random.nextInt(list.size());
				if (!isContain(temp, ra)) {
					temp.add(ra);
					dp = new DiscountPro();
					double price = list.get(ra).getPrice();
					double discount = random.nextDouble() * (price * 0.2);
					BigDecimal bd = new BigDecimal(price, mc);
					BigDecimal b = new BigDecimal(discount, mc);
					dp.setPreferentialPrice(Double.valueOf(bd.subtract(b).toString()));
					dp.setPro(list.get(ra));
					dList.add(dp);
				} else {
					i--; // 重新取值 回溯法
				}
			}
			temp.clear();
			return dList;
		}
	}

	/**
	 * 包含该值返回true
	 * 
	 * @param temp
	 * @param random
	 * @return
	 */

	private boolean isContain(List<Integer> temp, int random) {
		for (Integer integer : temp) {
			if (integer == random) {
				return true;
			}
		}
		return false;
	}

	// 通过ID查找商品
	public Product findProductById(int id) {
		ProductDao productDao = new ProductDao();
		return productDao.fingById(id);

	}

	// 修改商品
	public void modify(Product product, int i) {
		ProductDao productDao = new ProductDao();
		productDao.update(product, i);

	}

	// 根据ID查图片路径

	public String getImgById(String id) {
		ProductDao productDao = new ProductDao();
		return productDao.QueryImgById(id);
	}

	// 根据ID删除商品
	public void deleteProductById(int id) {
		ProductDao dao = new ProductDao();
		dao.deleteById(id);

	}

	// 分页查询
	public PageProductBean pageShow(String page) {

		ProductDao productDao = new ProductDao();
		PageProductBean bean = new PageProductBean();

		int totalPage = productDao.getTotalRows();
		bean.setTotalPage(totalPage);

		// 计算页数
		int pageCount = (totalPage + PageProductBean.PAGE_SIZE - 1) / PageProductBean.PAGE_SIZE;
		bean.setPagecount(pageCount);
		int p = 0;
		if (isNum(page)) {
			p = Integer.parseInt(page);
		}

		// 当前页数
		if (p == 0) {
			p = 1;
		}

		bean.setPage(p);
		List<ProductBean> list = productDao.pageShowDao(p, PAGE_SIZE);
		bean.setList(list);
		return bean;
	}

	public int getPageCount() {
		ProductDao productDao = new ProductDao();
		int totalPage = productDao.getTotalRows();
		// 计算页数
		int pageCount = (totalPage + PageProductBean.PAGE_SIZE - 1) / PageProductBean.PAGE_SIZE;
		return pageCount;
	}

	// 删除修改前的图片
	public void deletePic(int i, ServletContext con) {
		ProductDao dao = new ProductDao();
		String img = dao.findProImgById(i);
		if (!"".equals(img)) {
			FileUploadUtils.deletePic(con.getRealPath(img.substring(10)), img);
		}
	}

	/*
	 * 判断是否是数字
	 */
	private boolean isNum(String num) {
		try {
			Integer.parseInt(num);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	// 通过父Id查询所有商品
	public ProductListBean showProductByParentId(String twoId, String oneId, String currentP) {
		if (oneId != null) {
			// 通过oneId查询所有的商品
			if (isNum(oneId)) {
				ProductDao dao = new ProductDao();
				ProductListBean listBean = new ProductListBean();
				listBean = dao.queryProBeanByOneId(Integer.parseInt(oneId));
				// 设置商品分页
				List<Product> list = listBean.getPagePro().getList();
				PageProduct pageProduct = forwordPage(list, currentP);
				listBean.setPagePro(pageProduct);
				return listBean;
			}

		} else if (twoId != null) {
			if (NumUtils.isNum(twoId)) {
				ProductDao dao = new ProductDao();
				ProductListBean listBean = new ProductListBean();
				listBean = dao.queryProBeanByPid(Integer.parseInt(twoId));
				// 设置商品分页
				List<Product> list = listBean.getPagePro().getList();
				PageProduct pageProduct = forwordPage(list, currentP);
				listBean.setPagePro(pageProduct);
				return listBean;
			} else {
				return null;
			}
		}
		return null;

	}

	// 显示商品详细情况
	public ProductViewBean showProductView(String pid, String discountPrice) {
		ProductDao dao = new ProductDao();
		if (discountPrice != null) {
			// 是折扣商品
			if (isNum(pid)) {
				Product product = dao.fingById(Integer.parseInt(pid));
				ProductViewBean viewBean = new ProductViewBean();
				viewBean.setPro(product);
				viewBean.setDiscountPrice(Double.valueOf(discountPrice));
				return viewBean;
			}else{
				return null;
			}

		} else {
			// 普通商品
			if (isNum(pid)) {
				Product product = dao.fingById(Integer.parseInt(pid));
				ProductViewBean viewBean = new ProductViewBean();
				viewBean.setPro(product);
				viewBean.setDiscountPrice(null);
				return viewBean;
			}
			return null;

		}

	}

	// 最近浏览商品
	public List<Product> saveRecentPro(Product pro, List<Product> rec) {
		// 是否存在该商品
		if (rec != null) {
			if (rec.contains(pro)) {
				return rec;
			} else {
				if (rec.size() < 3) {
					rec.add(pro);
				} else {
					rec.remove(0);
					rec.add(pro);
				}
				return rec;
			}

		} else {
			rec = new ArrayList<Product>();
			rec.add(pro);
			return rec;
		}

	}

	/**
	 * 查找商品集合分页信息
	 * 
	 * @param keyName
	 * @param page
	 * @return
	 */
	public PageProduct serachProduct(String keyName, String page) {
		if (keyName == null) {
			return null;
		} else {
			ProductDao dao = new ProductDao();
			List<Product> list = dao.serachByName(keyName);
			PageProduct pageProduct = forwordPage(list, page);
			return pageProduct;
		}
	}

	private PageProduct forwordPage(List<Product> list, String page) {
		PageProduct bean = new PageProduct();

		int totalPage = list.size();
		bean.setTotalPage(totalPage);
		// 计算页数
		int pageCount = (totalPage + PageProduct.PAGE_SIZE - 1) / PageProduct.PAGE_SIZE;
		bean.setPagecount(pageCount);
		int p = 0;
		if (isNum(page)) {
			p = Integer.parseInt(page);
		}

		// 当前页数
		if (p == 0) {
			p = 1;
		}

		bean.setPage(p);
		List<Product> lisstPage = setLisstPage(list, p, PageProduct.PAGE_SIZE);
		bean.setList(lisstPage);
		return bean;
	}

	private List<Product> setLisstPage(List<Product> list, int currentP, int pageSize) {

		if (list.size() <= pageSize) {
			return list;
		} else if (currentP * pageSize >= list.size()) {
			return list.subList((currentP - 1) * pageSize, list.size());
		} else {
			return list.subList((currentP - 1) * pageSize, currentP * pageSize);
		}
	}

}
