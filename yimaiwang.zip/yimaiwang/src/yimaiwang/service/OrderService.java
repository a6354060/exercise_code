package yimaiwang.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import yimaiwang.dao.OrderDao;
import yimaiwang.dao.ProductDao;
import yimaiwang.dao.UserDao;
import yimaiwang.domain.User;
import yimaiwang.domain.order.OrderPageBean;
import yimaiwang.domain.order.Order;
import yimaiwang.domain.order.OrderBean;
import yimaiwang.domain.order.OrderDetailBean;
import yimaiwang.domain.order.OrderItem;
import yimaiwang.domain.product.Product;
import yimaiwang.domain.product.manage.PageProductBean;
import yimaiwang.domain.product.manage.ProductBean;
import yimaiwang.utils.NumUtils;
import yimaiwang.utils.PaymentUtil;

/**
 * 订单的业务类
 * 
 * @author hp
 *
 */
public class OrderService {
	/**
	 * 确认订单信息
	 * 
	 * @param map
	 * @param u
	 * @param orderId2 
	 * 
	 * @param ids
	 * @param totalmoney
	 */
	public Order addOrder(String money, HashMap<Product, Integer> map, User u, String orderId2) {
		// 生成订单号
		Order order = new Order();
		order.setId(orderId2);
		// 设置订单金额
		float m = Float.valueOf(money);
		order.setTotalprices(m);
		// 设置订单初始化状态 为未付款
		order.setStatu(0);
		// 设置收货地址
		order.setUaddress(u.getAddress());
		// 设置UID
		order.setUid(u.getId());

		OrderDao dao = new OrderDao();
		ArrayList<OrderItem> items = new ArrayList<OrderItem>();
		// 添加订单项
		Set<Entry<Product, Integer>> entrySet = map.entrySet();
		for (Entry<Product, Integer> entry : entrySet) {
			OrderItem item = new OrderItem();
			item.setOid(order.getId());
			item.setPid(entry.getKey().getId());
			item.setPro_count(entry.getValue());
			items.add(item);
		}
		order.setList(items);
		dao.addOrder(order);
		return order;

	}
/**
 * 分页显示业务类
 * @param page
 * @return 
 */
	public OrderPageBean pageShow(String page) {
		OrderDao orderDao = new OrderDao();
		OrderPageBean bean = new OrderPageBean();

		int totalPage = orderDao.getTotalRows();
		bean.setTotalPage(totalPage);

		// 计算页数
		int pageCount = (totalPage + OrderPageBean.PAGE_SIZE - 1) / OrderPageBean.PAGE_SIZE;
		bean.setPagecount(pageCount);
		int p = 0;
		if (NumUtils.isNum(page)) {
			p = Integer.parseInt(page);
		}

		// 当前页数
		if (p == 0) {
			p = 1;
		}

		bean.setCurrentPage(p);
		List<OrderBean> list = orderDao.pageShowDao(p, OrderPageBean.PAGE_SIZE);
		bean.setList(list);
		return bean;
	}
	/**
	 * 查询订详情
	 *  @param oid
	 * @param uid 
	 * @return 
	 */
  public OrderDetailBean orderDetail(String oid, String uid) {
     	
	    if(oid!=null&&uid!=null){
     		
     	 OrderDao dao=new OrderDao();
     	 OrderDetailBean orderDetail = dao.queryOrderDetail(oid);
     	 int u = Integer.parseInt(uid);
     	  UserDao userDao=new UserDao();
     	  User user = userDao.findById(u);
     	  orderDetail.setUser(user);
     	 return orderDetail;
	    }
	    return null;
   }
  // 更改商品库存量
	public void updateProInenv(HashMap<Product, Integer> map) {
		if(map!=null){
			ProductDao productDao=new ProductDao();
			
			Set<Entry<Product,Integer>> set = map.entrySet();
			for (Entry<Product, Integer> entry : set) {
				productDao.updateInevn(entry.getKey().getId(),entry.getValue());
			}
		}
		
	}
	//查询个人订单信息
	public OrderPageBean personOrder(int uid, String page) {
		OrderDao orderDao = new OrderDao();
		OrderPageBean bean = new OrderPageBean();

		int totalPage = orderDao.getTotalRows(uid);
		bean.setTotalPage(totalPage);

		// 计算页数
		int pageCount = (totalPage + OrderPageBean.PAGE_SIZE - 1) / OrderPageBean.PAGE_SIZE;
		bean.setPagecount(pageCount);
		int p = 0;
		if (NumUtils.isNum(page)) {
			p = Integer.parseInt(page);
		}

		// 当前页数
		if (p == 0) {
			p = 1;
		}

		bean.setCurrentPage(p);
		List<OrderBean> list = orderDao.personOrder(uid,p, OrderPageBean.PAGE_SIZE);
		bean.setList(list);
		return bean;
	}
	/**
	 * 根据ID删除订单
	 * @param oid
	 */
	public void deleteOrder(String oid) {
        if(oid!=null){
        	OrderDao dao=new OrderDao();
        	dao.deleteById(oid);
        }		
	}

}
