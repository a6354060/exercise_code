package yimaiwang.service;

import java.util.List;
import java.util.Properties;
import java.util.UUID;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.tomcat.util.buf.UDecoder;

import yimaiwang.dao.ProductGategroyDao;
import yimaiwang.dao.UserDao;
import yimaiwang.domain.User;
import yimaiwang.domain.UserPageBean;
import yimaiwang.domain.productGate.ProductGatePageBean;
import yimaiwang.domain.productGate.ProductOneBean;
import yimaiwang.utils.MD5Utils;

/**
 * 用户业务类
 * 
 * @author hp
 *
 */
public class UserService {

	public static final int CHECK_USER_EXESIT = 0;
	public static final int CHECK_EMAIL_EXESIT = 1;
	public static final int CHECK_USER_AVLIABLE = 2;
	public static final int CHECK_USER_NOT_AVLIABLE = 3;

	/**
	 * 登陆的处理方法
	 * 
	 * @param user
	 * @return false 登陆失败 true 登陆成功
	 */
	public User login(User user) {
		// 调用DAO层
		UserDao dao = new UserDao();
		user.setPassword(MD5Utils.md5(user.getPassword()));
		User user2 = dao.findByUsernameAndPassword(user);
		return user2;
	}

	// 注册方法
	public void regist(User user) {
		// 1 发送激活邮件
		String activecode = UUID.randomUUID().toString();
		user.setActivecode(activecode);
		user.setPassword(MD5Utils.md5(user.getPassword()));
		Properties props = new Properties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.host", "127.0.0.1");
		props.put("mail.smtp.auth", "true");// 连接认证
		props.put("mail.debug", "flase");// 在控制台显示连接日志信息
		Session session = Session.getInstance(props);

		Message message = new MimeMessage(session);
		try {
			Address address = new InternetAddress("service@hp.com");
			message.setFrom(address);
			Address Toaddress = new InternetAddress(user.getEmail());
			message.setRecipient(RecipientType.TO, Toaddress);
			message.setSubject("激活邮件");

			message.setContent("欢迎您注册易买网商城账号,请于24小时内点击下面链接激活账号<br>"
					+ "<a href=http://localhost/yimaiwang/activeServlet?activecode=" + activecode
					+ ">http://localhost/yimaiwang/activeServlet?activecode=" + activecode + "</a>",
					"text/html;charset=utf-8");
			Transport transport = session.getTransport();
			transport.connect("service@hp.com", "123");
			transport.sendMessage(message, message.getAllRecipients());
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

		UserDao dao = new UserDao();
		dao.registUser(user);
	}

	/**
	 * 激活用户
	 * 
	 * @param activecode
	 * @return
	 */
	public int activeUser(String activecode) {
		UserDao userDao = new UserDao();
		User user = userDao.fingByActivecode(activecode);
		if (user == null) {
			return 0;
		} else {
			if (System.currentTimeMillis() - user.getRegisttime().getTime() > 1000 * 1000 * 60 * 24) {
				return 1;
			} else {
				user.setState(1);
				userDao.activeUser(user);
				return 2;
			}
		}
	}

	/**
	 * 后台检查邮箱和用户名是否存在
	 */
	public int checkUser(User user) {
		List<User> list = null;
		if (user != null) {
			String name = user.getUsername();
			String email = user.getEmail();
			if (name != null && email != null) {
				UserDao userDao = new UserDao();
				list = userDao.findAll();
				if (list == null) {
					// 用户可以用
					return CHECK_USER_AVLIABLE;
				} else {
					for (User u : list) {
						if (name.equals(u.getUsername())) {
							// 用户不可以用
							return CHECK_USER_EXESIT;
						}

						if (email.equals(u.getEmail())) {
							// 用户不可以用
							return CHECK_EMAIL_EXESIT;
						}
					}

					return CHECK_USER_AVLIABLE;
				}
			}
		}
		return CHECK_USER_NOT_AVLIABLE;
	}

	/**
	 * 查询所有用户
	 */
	public List<User> queryAllUser() {
		UserDao dao = new UserDao();
		List<User> all = dao.findAll();
		return all;
	}

	/**
	 * 管理员直接添加用户 邮箱是直接激活的
	 * 
	 * @param user
	 */
	public void addUser(User user) {
		int statu = 1;
		user.setState(statu);
		String md5 = MD5Utils.md5(user.getPassword());
		user.setPassword(md5);
		UserDao dao = new UserDao();
		dao.insert(user);

	}

	/**
	 * 
	 * @param uid
	 */
	public User queryUserById(String uid) {
		User user = new User();
		if (isNum(uid)) {
			UserDao dao = new UserDao();
			user = dao.findById(Integer.parseInt(uid));
		}
		return user;
	}

	/*
	 * 判断是否是数字
	 */
	private boolean isNum(String num) {
		try {
			Integer.parseInt(num);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	// 更新用户信息
	public void updateUser(User user) {
		UserDao dao = new UserDao();
		user.setPassword(MD5Utils.md5(user.getPassword()));
		dao.update(user);
	}

	// 删除用户信息
	public void delete(String uid) {
		UserDao dao = new UserDao();
		if (isNum(uid)) {
			dao.delete(Integer.parseInt(uid));
		}

	}

	// 查询分页用户信息
	public UserPageBean UserPageShwoQuery(String p) {
		int page = 0;
		UserPageBean pageBean = new UserPageBean();

		UserDao dao = new UserDao();
		// 得到总共有多少数据项
		int allCount = dao.queryAllUserCount();
		pageBean.setTotalDataNum(allCount);

		// 总共分多少页
		int totalPage = (allCount + UserPageBean.PAGE_SIZE - 1) / UserPageBean.PAGE_SIZE;
		pageBean.setTotalPage(totalPage);

		if (isNum(p)) {
			page = Integer.parseInt(p);
		}

		if (page > totalPage) {
			page = totalPage;
		}
		if (page <= 0) {
			page = 1;
		}
		// 设置当前多少页
		pageBean.setCurrentPage(page);
		// 得到显示数据
		List<User> list = dao.queryCurrentPage(page, UserPageBean.PAGE_SIZE);
		pageBean.setList(list);
		return pageBean;
	}

	public int getTotalPage() {
		UserDao dao = new UserDao();
		// 得到总共有多少数据项
		int allCount = dao.queryAllUserCount();
		int totalPage = (allCount + UserPageBean.PAGE_SIZE - 1) / UserPageBean.PAGE_SIZE;
		return totalPage;
	}

	public void completeUser(User user, boolean isupdatePass) {
		UserDao dao = new UserDao();
		if(isupdatePass){
			user.setPassword(MD5Utils.md5(user.getPassword()));
		}
		dao.update(user);
	}

	public int checkUser(User user, User u) {
		List<User> list = null;
		if (user != null) {
			String name = user.getUsername();
			String email = user.getEmail();
			if (name != null && email != null) {
				UserDao userDao = new UserDao();
				list = userDao.findAll();
				if (list == null) {
					// 用户可以用
					return CHECK_USER_AVLIABLE;
				} else {
					for (User u1 : list) {
						if (name.equals(u1.getUsername())&&!name.equals(u.getUsername())) {
							// 用户不可以用
							return CHECK_USER_EXESIT;
						}

						if (email.equals(u1.getEmail())&&!email.equals(u.getEmail())) {
							// 用户不可以用
							return CHECK_EMAIL_EXESIT;
						}
					}

					return CHECK_USER_AVLIABLE;
				}
			}
		}
		return CHECK_USER_NOT_AVLIABLE;
	}

}
