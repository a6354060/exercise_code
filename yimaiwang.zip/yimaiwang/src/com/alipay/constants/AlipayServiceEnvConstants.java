

/**

 * Alipay.com Inc.

 * Copyright (c) 2004-2014 All Rights Reserved.

 */

package com.alipay.constants;


/**
 * 支付宝服务窗环境常量（demo中常量只是参考，需要修改成自己的常量值）
 * 
 * @author taixu.zqq
 * @version $Id: AlipayServiceConstants.java, v 0.1 2014年7月24日 下午4:33:49 taixu.zqq Exp $
 */
public class AlipayServiceEnvConstants {

    /**支付宝公钥-从支付宝服务窗获取*/
    public static final String ALIPAY_PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDDI6d306Q8fIfCOaTXyiUeJHkrIvYISRcc73s3vF1ZT7XN8RNPwJxo8pWaJMmvyTn9N4HQ632qJBVHf8sxHi/fEsraprwCtzvzQETrNRwVxLO5jVmRGi60j8Ue1efIlzPXV9je9mkjzOmdssymZkh2QhUrCmZYI/FCEa3/cNMW0QIDAQAB";

    /**签名编码-视支付宝服务窗要求*/
    public static final String SIGN_CHARSET      = "GBK";

    /**字符编码-传递给支付宝的数据编码*/
    public static final String CHARSET           = "GBK";

    /**签名类型-视支付宝服务窗要求*/
    public static final String SIGN_TYPE         = "RSA";
    
    
    public static final String PARTNER           = "2088102169486960";

    /** 服务窗appId  */
    //TODO !!!! 注：该appId必须设为开发者自己的服务窗id  这里只是个测试id
    public static final String APP_ID            = "2016080100143071";

    //开发者请使用openssl生成的密钥替换此处  请看文档：https://fuwu.alipay.com/platform/doc.htm#2-1接入指南
    //TODO !!!! 注：该私钥为测试账号私钥  开发者必须设置自己的私钥 , 否则会存在安全隐患 
    public static final String PRIVATE_KEY       = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBANWNhadINPYqj3aJITkNxmwA8FYQbTgU49rtNVYH6ZqJkSl0EK2sKq/erB+XvvakQgrzgg9vgm6n+rQoAfdb4X9lsjxkH9MXQCzB0O/FBJmjEp+haWoqrbFHV33QvWNrhqUn7DtpTt6Vk9Uf2nlO4O4XHBbTBjfc4dL2EG3Hz1NrAgMBAAECgYEA0GrbiyR8k9d7xmsVIpKgGZ5c8RH9FiPFMVAaosj8I1epdbSR5n3F93ixse+ubxZmYju/roLc4FRO6G63ZIumqZ4nofv6pPFiBnBpbTry3xSX6aCreRD80r8lK9H2w3jlwBHJ9rvFt9b0noCarunzciRkGnvvZXrjJBmobKah3pECQQD+2uoGnd3EelHsO7DmbpxA0bvv7MaxWr7N1UFlcfOUzmZqEe+49LR1Sh23uas7aaVtbxYODu9x7tMjywCphAgTAkEA1oMcIDIeMjWLKPZbspIXXqnO+GjhLHYsd1LgEwXFzfMQp8Zu96lvNaOeDOdgPAybQPeNjRB6ALrhk2QKJ1+iSQJARoWfUrtmfZL3jm4qEmmzNUCUR9z2Umdw+xYy5XZ118yRjHJwKncUZIxg0tE+787ZJwIhUTySx601oebvxPizHwJBAMRR68y/cYlMHZcYmOV99KtrR4NrISF66cku7Oob72NEICscXXSF+cSigMSYgSeT9gboSQEgYjgG0On+tZhBWxkCQDh5VbxobPx+LFJMyhmvpu1y2nS8l2Pre6pYWgQv6DtK8+idUZlGUk7CatDhlykk0zZ2c3mIr+w2ZjaZhu/+a2Y=";
    //TODO !!!! 注：该公钥为测试账号公钥  开发者必须设置自己的公钥 ,否则会存在安全隐患
    public static final String PUBLIC_KEY        = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDVjYWnSDT2Ko92iSE5DcZsAPBWEG04FOPa7TVWB+maiZEpdBCtrCqv3qwfl772pEIK84IPb4Jup/q0KAH3W+F/ZbI8ZB/TF0AswdDvxQSZoxKfoWlqKq2xR1d90L1ja4alJ+w7aU7elZPVH9p5TuDuFxwW0wY33OHS9hBtx89TawIDAQAB";

    /**支付宝网关*/
    public static final String ALIPAY_GATEWAY    = "https://openapi.alipaydev.com/gateway.do";

    /**授权访问令牌的授权类型*/
    public static final String GRANT_TYPE        = "authorization_code";
}